# PHASE REPORT — UI / Route Display

## 1. Files inspected during repository audit

Before writing any code, the uploaded ZIP was extracted and the following
were read in full:

- `app/ui/__init__.py`, `app/ui/guide_ui.py` (existing UI placeholder)
- `tests/ui/__init__.py` (existing UI test placeholder)
- `app/navigation/__init__.py`, `app/navigation/map_data.py`,
  `app/navigation/pathfinder.py`, `app/navigation/service.py`
- `app/guide/__init__.py`, `app/guide/content.py`, `app/guide/guide_service.py`
- `app/models/schemas.py`
- `app/decision/event_manager.py`, `app/decision/state_manager.py` (head)
- `app/robot/__init__.py`
- `app/main.py`
- `app/config.py`
- `docs/integration_contract.md` (in full)
- `docs/architecture.md`, `docs/contracts.md` (sizes checked; contract
  details confirmed already present/duplicated in `integration_contract.md`)
- `tests/test_guide.py`, `tests/test_decision.py` (for existing test style)
- `tests/navigation/__init__.py`
- `requirements.txt`
- Full repository directory tree (`app/`, `tests/`, `docs/`, `scripts/`)

Note: the ZIP also contains a nested, separate project directory
`ai-university-lab-guide/` at the repo root. It was left completely
untouched — nothing in this phase reads, writes, or reasons about it.

## 2. Existing contracts discovered

- `app/models/schemas.py` — canonical Vision/ML contracts
  (`BoundingBox`, `FaceDetection`, `DetectionResult`, `IntentType`,
  `IntentResult`). **No route, destination, or place contract exists
  here.**
- `app.guide.guide_service.GuideResponse` — stable, existing Guide
  output contract (`topic`, `title`, `summary`, `sections`,
  `spoken_text`, `timestamp`). Reused as-is; not duplicated.
- `app.decision.event_manager.ApplicationState` — existing Decision
  states: `WAITING, GREETING, GUIDE_MENU, EXPLAINING, COOLDOWN, ERROR`.
  This does **not** match the system-status vocabulary requested for
  this phase (`WAITING, LISTENING, PROCESSING, NAVIGATING, ARRIVED,
  ERROR`) — it is a different, only partially overlapping set, so it
  was not reused as-is (see gap #1 below).
- `docs/integration_contract.md` explicitly documents the intended
  dependency direction `UI → Models, Guide`, confirming UI is meant to
  depend on Guide's existing contract and on `app.models`, not on
  Navigation directly by import.

## 3. UI architecture implemented

```
Domain Data
    v
app.ui.view_models     — display-ready dataclasses/enum (SystemStatus,
                          RouteStep, RouteView, PlaceInfoView,
                          GuideContentView, NavigationView)
    v
app.ui.route_display    — builders/adapters: turn plain route data (or
                          an existing GuideResponse) into the above
                          view models; "safe" builder never raises for
                          malformed/missing input, mirroring
                          GuideService's own "Topic Unavailable"
                          pattern
    v
app.ui.renderer          — Renderer interface + TextRenderer
                          (deterministic plain-text output); the sole
                          replaceable extension point for a future
                          Terminal/GUI/Web renderer
```

`app/ui/__init__.py` re-exports the public API of all three modules.
`app/ui/guide_ui.py` is kept as a thin, backward-compatible re-export
of `route_display.guide_response_to_view` (its original placeholder
docstring's stated responsibility), so nothing that already imports
`app.ui.guide_ui` breaks, without duplicating adapter logic.

## 4. Files added

```
app/ui/view_models.py
app/ui/route_display.py
app/ui/renderer.py
tests/ui/test_view_models.py
tests/ui/test_route_display.py
tests/ui/test_renderer.py
tests/ui/test_isolation.py
PHASE_REPORT.md
ui-route-display-phase.tar.gz
```

## 5. Existing files modified

Only files that were **already part of the existing UI module** (per
the phase instructions' explicit allowance) were modified — both were
docstring-only placeholders with zero executable logic before this
phase:

- `app/ui/__init__.py` — was a docstring-only placeholder; now exports
  the real public API implemented in this phase.
- `app/ui/guide_ui.py` — was a docstring-only placeholder; now a thin
  re-export (see §3) fulfilling its originally-stated responsibility.
- `tests/ui/__init__.py` — was a docstring-only "no tests yet"
  placeholder; now a docstring describing the test package added in
  this phase.

**No other existing file was modified, deleted, renamed, or
reformatted.** This was verified with a full recursive `diff -rq`
between the original uploaded ZIP and the final tree: the only
differences outside `app/ui/`, `tests/ui/`, and `PHASE_REPORT.md` /
the archive are `__pycache__/` directories, which are excluded from
the archive and not part of the source tree.

## 6. Confirmation: no protected module was modified

Confirmed by inspection and by `diff -rq` against the original
extracted ZIP: `app/vision/`, `app/robot/`, `app/ml/`, `app/dl/`,
`app/decision/`, `app/navigation/`, `app/guide/`, `app/models/`,
`app/main.py`, `app/config.py`, `docs/`, `scripts/`, and every existing
test file outside `tests/ui/` are byte-for-byte unchanged.

## 7. Dependency / isolation verification

- Manual review of every `import`/`from` line in `app/ui/*.py` (see
  below) shows imports limited to: `app.guide.guide_service`,
  `app.utils.logger`, `app.ui.*` (internal), plus the standard library
  (`dataclasses`, `enum`, `typing`, `abc`).
- **No import of `app.robot`, `app.vision`, `app.ml`, `app.dl`,
  `app.main`, or `app.navigation` exists anywhere in `app/ui/`.**
  `app.navigation` is intentionally not imported — see Gap #1 below.
- This is additionally enforced by an automated, static-analysis test:
  `tests/ui/test_isolation.py::TestUiModuleIsolation
  ::test_no_ui_source_file_imports_a_protected_module`, which parses
  every `app/ui/*.py` file's AST and fails if any forbidden module is
  imported — not just at test-run time, but as a standing guard
  against future regressions in this module.
- `app/models/schemas.py` was not modified, and no new symbols were
  added to it — the route/place/status view models were deliberately
  kept UI-owned (see Gap #1) rather than injected into the shared
  schema file.

```
$ grep -rn "^import\|^from" app/ui/*.py
app/ui/__init__.py:      from app.ui.renderer import ...
app/ui/__init__.py:      from app.ui.route_display import (...)
app/ui/__init__.py:      from app.ui.view_models import (...)
app/ui/guide_ui.py:      from app.ui.route_display import guide_response_to_view
app/ui/guide_ui.py:      from app.ui.view_models import GuideContentView
app/ui/renderer.py:      from abc import ABC, abstractmethod
app/ui/renderer.py:      from typing import List
app/ui/renderer.py:      from app.ui.view_models import (...)
app/ui/route_display.py: from typing import List, Optional, Sequence, Tuple
app/ui/route_display.py: from app.guide.guide_service import GuideResponse
app/ui/route_display.py: from app.ui.view_models import (...)
app/ui/route_display.py: from app.utils.logger import get_logger
app/ui/view_models.py:   from dataclasses import dataclass, field
app/ui/view_models.py:   from enum import Enum
app/ui/view_models.py:   from typing import List, Optional
```

## 8. Tests added

56 tests across 4 files in `tests/ui/`:

- `test_view_models.py` (23 tests) — validation rules for `SystemStatus`,
  `RouteStep`, `PlaceInfoView`, `RouteView`, `GuideContentView`,
  `NavigationView`, including all six required system statuses.
- `test_route_display.py` (19 tests) — builder/adapter behavior:
  valid multi-step routes, empty routes, malformed step data, invalid
  destination names, unknown-destination controlled view, empty
  (no-destination) view, arrival view, error view, and the
  `guide_response_to_view` adapter against a real `GuideService`
  response (both a valid topic and an unavailable one).
- `test_renderer.py` (11 tests) — `TextRenderer` output for every
  system status, a multi-step route, current-step marking, an empty
  route, arrival state, error state, unknown destination, empty
  destination, place info without a route, and guide content
  rendering (with and without sections).
- `test_isolation.py` (3 tests) — `app.ui` and each submodule import
  without error (no hardware/network required), plus the static
  no-protected-import guard described in §7.

All tests are deterministic, offline, hardware-free, and require no
network access — they use only synthetic/plain input data and the
real (but hardware-free) `GuideService`.

**Note on test framework:** tests are written with Python's standard
library `unittest.TestCase` rather than `pytest` fixtures/classes.
This sandboxed execution environment has no network access and
`pytest` (listed in `requirements.txt` but not preinstalled here)
could not be installed to actually run `python -m pytest -q` in this
session (`pip install pytest` failed with "No matching distribution
found" — no PyPI egress available). `unittest.TestCase`-based tests
are fully compatible with and collectible by `pytest` (pytest natively
discovers and runs `unittest.TestCase` subclasses), so `python -m
pytest -q` will run them normally in the project's own development
environment once `pytest` is installed there. In the meantime, all 56
tests were verified in this session using the standard library test
runner directly.

## 9. Final test result (this session)

`pytest` was not runnable in this sandbox (see §8). Verified instead
with:

```
$ python3 -m unittest discover -s tests/ui -v
...
----------------------------------------------------------------------
Ran 56 tests in 0.008s

OK
```

All 56 tests pass. Existing modules were also spot-checked to confirm
this phase did not break anything importable:

```
$ python3 -c "import app.main, app.config, app.decision.state_manager, \
  app.decision.event_manager, app.guide, app.robot, app.navigation, \
  app.vision.detector_interface, app.models.schemas, app.utils.logger"
OK app.main
OK app.config
OK app.decision.state_manager
OK app.decision.event_manager
OK app.guide
OK app.robot
OK app.navigation
OK app.vision.detector_interface
OK app.models.schemas
OK app.utils.logger
```

No existing test file (outside `tests/ui/`) was run, modified, or
otherwise touched in this phase.

## 10. Integration gaps discovered

**Gap #1 — `app.navigation` has no real contract to consume.**
`app/navigation/__init__.py`, `map_data.py`, `pathfinder.py`, and
`service.py` are all docstring-only placeholders with zero executable
logic (confirmed by reading every line of each file). No
`RouteRequest`/`RouteResult` type exists anywhere in the project.
Per `docs/integration_contract.md`, UI's dependency direction is
`UI → Models, Guide` — not `UI → Navigation` — so this is consistent
with the documented plan, but it does mean this phase cannot adapt a
*real* Navigation output; there is nothing to adapt yet.

**Resolution taken (per the phase instructions: "prefer a UI-owned
adapter or view model; do NOT modify shared contracts"):** route,
step, and place-info view models (`RouteView`, `RouteStep`,
`PlaceInfoView`) were defined as UI-owned view models in
`app/ui/view_models.py`, along with plain-data builder functions in
`app/ui/route_display.py` that accept primitive route data (a
destination name, a sequence of `(instruction, distance, duration)`
tuples, etc.) rather than a Navigation-published type. `app.models.schemas`
was **not** modified — no `RouteResult` was invented and injected into
the shared contract file. When `app.navigation.service` is eventually
implemented and publishes a real `RouteResult` (or a
`RouteResult`/`RouteRequest` contract is added to `app.models.schemas`),
a small, additive adapter function can translate that into the
existing `RouteView`/`RouteStep` view models without any change to
this phase's public view-model shapes — the same "producing module
owns its own contract until it exists, consuming module adapts"
pattern already established by `GuideResponse` in this codebase.

**Gap #2 — The requested system-status vocabulary does not match
`app.decision.event_manager.ApplicationState`.**
The phase objective's required statuses are `WAITING, LISTENING,
PROCESSING, NAVIGATING, ARRIVED, ERROR`. The existing
`ApplicationState` enum is `WAITING, GREETING, GUIDE_MENU, EXPLAINING,
COOLDOWN, ERROR`. Only `WAITING` and `ERROR` overlap; the rest diverge
in both directions (`ApplicationState` has guide-menu/greeting
concepts UI's status doesn't need, and UI's status needs
listening/processing/navigating/arrived concepts `ApplicationState`
doesn't have). **Resolution taken:** a separate, UI-owned
`SystemStatus` enum was defined in `app/ui/view_models.py` rather than
reusing or silently redefining `ApplicationState`. `app.decision.event_manager`
was not modified.

## 11. Limitations

- Because `app.navigation` is unimplemented, this phase could not be
  tested against a real, live route computation — only against
  synthetic/plain route data passed directly to the builder functions,
  and this is by design (a presentation layer must be testable
  independent of the algorithms that will eventually feed it).
- `TextRenderer` produces plain text only (no ANSI color, no
  Arabic/English localization, no map visualization). The phase
  instructions explicitly call for lightweight, deterministic output
  and warn against implementing unnecessary future features, so these
  were left as clearly-named extension points (a second `Renderer`
  implementation, a `locale`/translation layer, a map overlay) rather
  than being built out now.
- `python -m pytest -q` itself could not be executed in this sandboxed
  session due to the lack of network access to install `pytest` (see
  §8/§9 for the equivalent verification performed instead, and why the
  added tests remain fully pytest-compatible).
