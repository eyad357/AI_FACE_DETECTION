"""
UI module — Route Display presentation layer.

Owner: Person 2 (Robotics / Interaction).

Implemented in this phase (UI / Route Display workstream): a
presentation-only layer that displays destination, route information,
current navigation state, step-by-step route instructions,
estimated distance/duration (when provided), place information (when
available), and system status (WAITING, LISTENING, PROCESSING,
NAVIGATING, ARRIVED, ERROR).

This package is a PRESENTATION LAYER ONLY. It does not calculate
routes, does not implement navigation/pathfinding algorithms, does not
classify intents, does not perform computer vision, does not control
the robot, and does not orchestrate the application.

Structure:

    Domain Data
        v
    UI View Model / Adapter    app.ui.view_models / app.ui.route_display
        v
    Renderer                   app.ui.renderer

Dependency rules (see docs/integration_contract.md, "UI -> Models,
Guide"):
    - MAY import app.models (shared contracts)
    - MAY import app.guide (existing, stable Guide public API)
    - MAY import app.utils.logger
    - MUST NOT import app.robot, app.vision, app.ml, app.dl, or
      app.main

app.navigation is still an unimplemented placeholder as of this phase
(no `RouteResult`/`RouteRequest` contract exists yet — see
app/navigation/__init__.py). This package therefore does not import
app.navigation; route/place data is consumed through the UI-owned
adapters in app.ui.route_display until Navigation publishes a real
contract. See PHASE_REPORT.md for the full integration-gap writeup.
"""

from app.ui.renderer import Renderer, TextRenderer
from app.ui.route_display import (
    arrived_view,
    build_navigation_view_safe,
    build_place_info_view,
    build_route_view,
    empty_destination_view,
    error_view,
    guide_response_to_view,
    navigating_view,
    unknown_destination_view,
)
from app.ui.view_models import (
    GuideContentView,
    NavigationView,
    PlaceInfoView,
    RouteStep,
    RouteView,
    SystemStatus,
)

__all__ = [
    # view models
    "SystemStatus",
    "RouteStep",
    "RouteView",
    "PlaceInfoView",
    "NavigationView",
    "GuideContentView",
    # builders/adapters
    "build_route_view",
    "build_place_info_view",
    "build_navigation_view_safe",
    "navigating_view",
    "arrived_view",
    "error_view",
    "unknown_destination_view",
    "empty_destination_view",
    "guide_response_to_view",
    # renderer
    "Renderer",
    "TextRenderer",
]
