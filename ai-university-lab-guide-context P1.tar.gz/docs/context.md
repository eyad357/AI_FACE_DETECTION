# Context — Combined Request Planning & Response Contract

Owner: Person 1 (AI / Intelligence).

## 1. Purpose

Given an already-classified `IntentResult` (produced by `app.ml`),
determine which capabilities are required to fulfill the request.
Nothing more.

Context is the bridge between "what did the student ask for"
(`app.ml`'s job) and "which modules need to run" — without itself
running any of them.

## 2. Responsibility

Context is responsible for:
- interpreting an existing `IntentResult` contract
- determining required capabilities (`Navigation`, `Guide`, both, or
  neither)
- representing the execution plan for a request (`RequestPlan`)
- defining the shape of a combined-response contract
  (`CombinedResponse`) for future integration to populate
- safely handling every `IntentType` value, including `UNKNOWN`
- remaining fully independent from every implementation module

Context is **not** responsible for: ML classification, Navigation
routing, Guide data lookup, Robot control, speech, Vision, DL, UI, or
final orchestration (`app.main`).

## 3. `RequestPlan`

Defined in `app/models/schemas.py` (the project's single canonical
contracts module, alongside `IntentResult`, `GestureResult`, and
`NavigationResult`):

```python
class Capability(Enum):
    NAVIGATION = "NAVIGATION"
    GUIDE = "GUIDE"

@dataclass(frozen=True)
class RequestPlan:
    intent: IntentType
    required_capabilities: Tuple[Capability, ...] = ()
    supported: bool = True
    reason: Optional[str] = None
```

Validated invariants (`__post_init__`): `intent` must be an
`IntentType`; `required_capabilities` must be a tuple of `Capability`;
`reason` must be set whenever `supported` is `False`.

`app.models.schemas` was inspected first, per this phase's own
instructions, and confirmed no suitable `RequestPlan` already existed
— this is a new, minimal, backward-compatible addition (append-only;
`IntentResult`, `GestureResult`, and `NavigationResult` are untouched).

## 4. Supported intents

| `IntentType` | `required_capabilities` | `supported` |
|---|---|---|
| `INFORMATION` | `(GUIDE,)` | `True` |
| `NAVIGATION` | `(NAVIGATION,)` | `True` |
| `COMBINED` | `(NAVIGATION, GUIDE)` | `True` |
| `HELP` | `()` | `True` (see below) |
| `UNKNOWN` | `()` | `False` (see below) |

**`HELP`:** per `IntentType`'s own existing docstring (`app.ml`), HELP
means *"the student doesn't know what to ask"* — a self-contained
guidance response, not a Navigation or Guide data request. So
`required_capabilities=()`, `supported=True`, with `reason` explaining
why no capability is needed. This is "following the existing
`IntentResult` semantics" as instructed — no new meaning was invented
for `HELP`.

**`UNKNOWN`:** ML's own low-confidence/unclassifiable fallback (see
`app.ml`). Context cannot safely guess a capability for it, so
`required_capabilities=()`, `supported=False`, with `reason` set. This
is handled gracefully — `ContextService.plan()` never raises for
`UNKNOWN`, it returns a normal `RequestPlan` with `supported=False`.

The mapping is a plain dict inside `app.context.service`
(`_CAPABILITY_MAP`), intentionally not itself a “clever” classifier —
it is a direct, literal lookup table, matching this phase's explicit
scope (map an already-known intent to capabilities; never re-derive
intent from text).

## 5. Combined request behavior

For `COMBINED`, `RequestPlan.required_capabilities` is
`(Capability.NAVIGATION, Capability.GUIDE)` — both needed. Context does
**not** call Navigation or Guide itself (forbidden — see "Dependency
boundaries" below); it only identifies that both are required. A
future orchestration layer (`app.main`) is responsible for actually
invoking both and assembling their results.

## 6. `CombinedResponse`

Also defined in `app/models/schemas.py`:

```python
@dataclass(frozen=True)
class CombinedResponse:
    navigation_result: Optional[NavigationResult] = None
    guide_response: Optional[object] = None
```

**Why `guide_response` is untyped (`object`, not `GuideResponse`):**
Context is forbidden from importing `app.guide` (see below), so it
cannot reference the real `app.guide.guide_service.GuideResponse`
type. `navigation_result` *is* properly typed as `NavigationResult`
because that type already lives in the shared `app.models.schemas`
module — importing it does not require importing `app.navigation`
itself. This asymmetry is a direct, documented consequence of
`app.guide`'s own earlier design decision (see `docs/guide.md`,
"Why `GuideResponse` was not moved to `app.models.schemas`") to keep
`GuideResponse` module-local rather than shared; Context works around
it rather than trying to resolve it, per this phase's own instruction
("if a boundary is unclear, preserve the existing architecture and
document the ambiguity — do not solve ambiguity by modifying protected
modules").

**Partial results (one branch succeeds, one fails):**
`NavigationResult` already carries its own `success`/`error` fields
(see `docs/navigation.md`), so a failed Navigation attempt is
represented as `CombinedResponse(navigation_result=NavigationResult(success=False, error=...))`
— never by leaving the field `None`, which is reserved for "not
attempted." `guide_response` is opaque to Context, so the future
integration layer that actually calls Guide is responsible for
however it represents a Guide-side failure (e.g. Guide's existing
`topic=None` "unavailable" convention — see `docs/guide.md`). Either
way, `CombinedResponse`'s two fields are fully independent: a problem
on one side never discards or invalidates a successful result on the
other, because there is no cross-field validation coupling them.

`CombinedResponse` is a pure data contract — it contains no
`RobotCommand`, Robot SDK object, UI object, camera object, or ML
model object, and Context never constructs a populated instance of it
(only future integration will, once it has actually called Navigation
and Guide).

## 7. Public API

```python
from app.context.service import ContextService
from app.models.schemas import IntentResult, IntentType

context = ContextService()
plan = context.plan(IntentResult(intent=IntentType.COMBINED, confidence=0.9, raw_text="..."))
# RequestPlan(intent=IntentType.COMBINED,
#             required_capabilities=(Capability.NAVIGATION, Capability.GUIDE),
#             supported=True, reason=None)
```

`ContextService` has exactly one public method: `plan(intent_result) ->
RequestPlan`. It is a pure function of its input — no state, no I/O,
fully deterministic. Passing anything other than an `IntentResult`
raises `TypeError` immediately (Context consumes the existing
`IntentResult` contract only; it never inspects or classifies raw
text).

## 8. Dependency boundaries

Enforced by `scripts/check_context_dependencies.py` and
`tests/context/test_dependencies.py` (AST-based):

- `app.context` imports only `app.models`, `app.config`, `app.utils`,
  and its own submodules.
- `app.context` **does not** import `app.ml`, `app.dl`, `app.vision`,
  `app.navigation`, `app.guide`, `app.robot`, `app.ui`, or `app.main`.
- No circular imports (`app.models`/`app.config` do not import
  `app.context`).
- No text-classification code (no `TfidfVectorizer`,
  `LogisticRegression`, `sklearn`, or `joblib` references anywhere in
  `app/context/`) — statically verified, not just documented.

**Decision boundary:** `app.decision` was inspected (per this phase's
instructions) and found to contain **no existing handling of
`IntentResult`, `IntentType`, `HELP`, or `UNKNOWN`** — Decision's
current state machine (`GuideTopic`-based menu navigation) predates
ML/Context entirely and has never consumed ML's output. There is
therefore no existing Decision-layer behavior for Context to respect
or duplicate; this boundary is genuinely open for a future phase to
define, and is left undefined here rather than guessed at.

## 9. Future integration boundary

Context is **not** wired into `app.main`, `app.decision`,
`app.navigation`, or `app.guide` in this phase. The future,
not-yet-implemented flow:

```
Student Question
      ↓
     ML
      ↓
  IntentResult
      ↓
   Context
      ↓
  RequestPlan
      ↓
   main.py
   /     \
  ↓       ↓
Navigation  Guide
  ↓          ↓
NavigationResult
            GuideResponse
      \      /
       \    /
   CombinedResponse
```

**Context does not perform ML. Context does not perform Navigation.
Context does not perform Guide retrieval. Context does not control
Robot. Context does not replace `main.py`.**

## 10. Testing

```bash
# Context tests only
pytest tests/context/ -v

# Full suite
pytest -v
```

`tests/context/` covers: capability mapping for
`INFORMATION`/`NAVIGATION`/`COMBINED`, `HELP`'s existing-semantics
handling, `UNKNOWN`'s safe unsupported handling, invalid-input
`TypeError` behavior, the `RequestPlan` and `CombinedResponse`
contracts (including partial-failure representation), determinism
(same `IntentResult` → same `RequestPlan`, confidence/raw_text don't
affect planning), the full forbidden-import list via AST inspection,
absence of any ML-library reference, and hardware/network
independence (pure in-memory function, no external resources).

All tests run with no camera, Robot, Robot SDK, ML model, DL, Vision,
Navigation implementation, Guide implementation, UI, or network
dependency.

## 11. Extension guidelines

To add a new `IntentType` member's plan in the future:

1. Add the capability mapping to `_CAPABILITY_MAP` in
   `app/context/service.py` (or a dedicated `HELP`/`UNKNOWN`-style
   branch in `plan()` if it needs no capability).
2. Add a test case to `tests/context/test_service.py` asserting the
   expected `required_capabilities`/`supported`/`reason`.
3. Re-run `pytest tests/context/` and the full suite to confirm zero
   regressions.
4. Do **not** add capability-specific logic (e.g. anything that
   inspects `raw_text`) — Context's mapping must stay a pure,
   deterministic function of `.intent` alone.
