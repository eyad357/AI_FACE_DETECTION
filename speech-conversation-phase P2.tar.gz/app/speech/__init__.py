"""
Speech & Conversation — dialogue/text-response layer for the AI
University Lab Guide Robot.

Owner: Person 2 (Robotics / Interaction) — see docs/contracts.md,
"Ownership" table ("Speech" is explicitly listed under Person 2).

Responsibility: turn a student's free-text utterance into a natural
language TEXT response, while tracking lightweight conversation
context (topic, destination, pending clarification, language) across
turns. This module answers "what should the robot SAY next?" — it
never decides *whether* to greet (Decision's job), *what* factual
content a topic contains (Guide's job), *how* to compute a route
(Navigation's job — not yet implemented), *what* the student's intent
statistically is (ML's job), or *how* text becomes physical robot
speech/actuation (Robot's job).

Flow:

    Student Utterance (str)
          |
          v
    ConversationInput            (app.speech.conversation)
          |
          v
    ConversationService.handle() (app.speech.conversation)
          |   uses ConversationContext (app.speech.context)
          |   uses language-aware templates (app.speech.language)
          v
    ConversationResponse.spoken_text  (app.speech.response)

This package contains:
    context.py       ConversationContext — lightweight per-session state
    language.py       Language enum + English/Arabic phrase templates
    response.py       ConversationResponse / ConversationResponseType
    conversation.py   ConversationInput + ConversationService (public API)
    knowledge.py       Small, explicitly-labeled PLACEHOLDER local
                        location knowledge, used only when no caller-
                        supplied information/destination text is given
                        (see knowledge.py docstring and PHASE_REPORT.md
                        for the integration gap this covers).

--------------------------------------------------------------------
ISOLATION GUARANTEES (enforced — see tests/speech/test_isolation.py)
--------------------------------------------------------------------

This module and everything under app/speech/ MUST NOT import:

    - app.robot   (no Robot SDK access, no speech execution, no
                    RobotCommand/RobotCommandType creation)
    - app.ml      (no statistical/ML intent classification; the
                    caller MAY pass an already-classified
                    app.models.schemas.IntentType/IntentResult in,
                    but this module never imports app.ml itself)
    - app.vision  (no camera/perception dependency)
    - app.dl      (no gesture-recognition dependency)
    - app.main    (no orchestration dependency; this module is a
                    leaf, callable BY a future orchestrator, never
                    the other way around)

This module produces TEXT ONLY (`ConversationResponse.spoken_text`).
It never executes speech, never touches Robot hardware/SDK/commands,
and never modifies `RobotCommandType`. A future orchestration layer
(app.main, not implemented in this phase) may take
`ConversationResponse.spoken_text` and hand it to
`app.robot.RobotController.speak()` — that wiring is explicitly OUT
OF SCOPE for this phase.

This module also does not import app.ml, so it cannot perform
statistical intent classification; where a caller has already run
`app.ml.service.MLIntentService.predict()`, the resulting
`app.models.schemas.IntentType` may be passed into
`ConversationInput.intent`. When no such caller-provided intent is
given, this module falls back to its own tiny, deterministic,
NON-ML, keyword-based heuristic (see `conversation.py`,
`_infer_local_intent`) purely so the module remains independently
testable and usable without a caller. This heuristic is not, and does
not attempt to be, a statistical classifier.
"""

from __future__ import annotations

from app.speech.context import ConversationContext
from app.speech.conversation import ConversationInput, ConversationService
from app.speech.language import Language
from app.speech.response import ConversationResponse, ConversationResponseType

__all__ = [
    "ConversationContext",
    "ConversationInput",
    "ConversationService",
    "ConversationResponse",
    "ConversationResponseType",
    "Language",
]
