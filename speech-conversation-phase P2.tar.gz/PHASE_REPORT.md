# PHASE_REPORT — Speech & Conversation

## 1. Files inspected during the repository audit

The uploaded ZIP contains a top-level extracted folder,
`AI_FACE_DETECTION-main/`, which itself contains **two** copies of the
project: the actual top-level `app/`, `tests/`, `docs/`, `README.md`
(the current, Phase-7-and-later source of truth, matching the
top-level `README.md`'s own description of "Current phase: Phase 7"
plus a "Future Architecture" section describing `app/ml`, `app/dl`,
`app/navigation`, `app/ui` as scaffolded), and a nested
`ai-university-lab-guide/` subdirectory that is an **older**,
partially-diverged snapshot (e.g. it lacks the trained ML artifacts —
`app/ml/artifacts/intent_classifier.joblib`,
`app/ml/dataset/intents.csv`, `app/ml/inference/inference.py`,
`app/ml/training/train.py` — that the top-level `app/ml` already has),
plus several top-level `*.tar.gz` files that appear to be prior phase
deliverable archives. The top-level `app/`/`tests/`/`docs/`/`README.md`
were used as the source of truth; the nested
`ai-university-lab-guide/` directory and all `*.tar.gz` files were
**not** touched, read for logic, or used in any way.

Files/directories actually inspected:

- `README.md` (full) — current phase, architecture, module
  responsibilities, ownership, future roadmap.
- `docs/architecture.md`
- `docs/contracts.md` (full) — ownership table, dependency rules,
  protected modules, contract-location philosophy.
- `docs/integration_contract.md`
- `docs/ml.md`
- `app/main.py` — read only, to confirm current orchestration scope
  and that it is not touched.
- `app/config.py` — read only.
- `app/models/schemas.py` (full) — confirmed `IntentType`/`IntentResult`
  exist; confirmed no `ConversationInput`/`ConversationResponse`/
  `ConversationContext` exists anywhere.
- `app/ml/__init__.py`, `app/ml/service.py` (full) — confirmed
  `MLIntentService.predict()` → `IntentResult` is implemented (not
  just scaffolded, despite the README's older "Future Architecture"
  table saying "Scaffolded" — the artifacts/dataset/inference files
  prove it was completed after that README section was last written).
- `app/guide/guide_service.py`, `app/guide/content.py` (full) —
  confirmed `GuideResponse`/`GuideService.get_topic_content()` pattern
  and its "contract lives in the producing module, not
  app.models" precedent, which this phase follows for
  `ConversationResponse`/`ConversationInput`.
- `app/navigation/service.py`, `app/navigation/__init__.py` (full) —
  confirmed Navigation is still an unimplemented placeholder (no
  `RouteResult`/`RouteRequest` exist yet to reuse).
- `app/decision/event_manager.py` (partial) — confirmed
  `DecisionEvent`/`GuideTopic` pattern (contract lives with producer).
- `app/robot/robot_commands.py`, `app/robot/robot_controller.py` —
  read only, to confirm `RobotCommandType` and to guarantee this phase
  never references it (see isolation tests).
- `app/utils/logger.py` — confirmed `get_logger(__name__)` convention,
  reused by `app.speech`.
- `tests/test_guide.py` — read for existing test style/conventions.
- `tests/ml/`, `tests/dl/`, `tests/navigation/`, `tests/ui/` — existing
  subdirectory test layout, confirming `tests/speech/` as a new
  subdirectory follows an established pattern.
- Repository-wide `grep` for "speech" / "conversation" (case
  insensitive) across `app/`, `tests/`, `docs/`, `README.md` — the
  only pre-existing hits were the word "Speech" in
  `docs/contracts.md`'s ownership table (listing it under Person 2,
  not implemented anywhere) and "spoken_text"/"speech synthesis"
  mentions inside `app/robot` and `app/guide` docstrings/tests
  describing what those modules explicitly do *not* do. **No existing
  Speech/Conversation module, contract, or test existed anywhere in
  the repository.**

## 2. Existing contracts/services discovered

| Contract | Location | Used by this phase? |
|---|---|---|
| `IntentType` / `IntentResult` | `app.models.schemas` | Yes — `ConversationInput.intent: Optional[IntentType]` accepts a caller-provided, already-classified intent. `app.speech` never imports `app.ml` itself. |
| `GuideResponse` | `app.guide.guide_service` | Not imported directly (this phase does not own Guide data and Guide is a protected module). Instead, `ConversationInput.information_text` lets a future caller pass `GuideResponse.spoken_text` straight through. |
| `GuideTopic` | `app.decision.event_manager` | Not imported (would require depending on Decision, which this phase does not own or need). |
| `RouteRequest`/`RouteResult` | *(planned, not implemented)* `app.navigation` | N/A — Navigation is still an empty placeholder; nothing to reuse. |
| `RobotCommandType`/`RobotCommand` | `app.robot.robot_commands` | Not imported, not referenced, not modified — verified by `tests/speech/test_isolation.py`. |

No existing contract was a compatible match for a free-text
conversational turn with clarification/confirmation/context, so two
new, additive, Speech-owned contracts were created
(`ConversationInput`, `ConversationResponse`) plus one supporting type
(`ConversationContext`) — following the same "contract lives with its
producing module" precedent already set by `DecisionEvent` and
`GuideResponse` (see `docs/contracts.md`, "Communication philosophy").

## 3. Speech & Conversation architecture implemented

```
app/speech/
    __init__.py       Public exports + isolation guarantees (docstring)
    language.py        Language enum, detect_language(), phrase templates (EN/AR)
    context.py          ConversationContext (immutable, per-turn state)
    response.py         ConversationResponse / ConversationResponseType
    conversation.py     ConversationInput + ConversationService (public API)
    knowledge.py         Small, explicitly-labeled placeholder location lookup
                          (fallback only — caller-supplied
                          information_text/destination always wins)
```

Flow:

```
Student Utterance (str)
    |
    v
ConversationInput                (app.speech.conversation)
    |
    v
ConversationService.handle()      -- language resolution
    |                              -- pending-clarification short-circuit
    |                              -- intent resolution (caller-provided
    |                                 IntentType, else local non-ML heuristic)
    |                              -- per-intent handler (greeting / help /
    |                                 reset / navigation / information /
    |                                 confirm-yes / confirm-no / unknown)
    v
ConversationResponse.spoken_text  (app.speech.response)
    + updated ConversationContext (app.speech.context)
```

Design decisions of note:

- **`ConversationContext` is immutable** (`@dataclass(frozen=True)`),
  updated only via `dataclasses.replace` (`with_updates()`), and
  **`ConversationService` holds no mutable instance state** — every
  call is a pure function of its `ConversationInput`
  (`ConversationInput.context` in, updated context out). This makes
  every scenario fully deterministic and independently testable, the
  same pattern `app.ml.service.MLIntentService` already uses.
- **Non-ML local intent inference** (`_infer_local_intent` in
  `conversation.py`) is a small, deterministic, keyword/substring
  matcher (bilingual EN/AR keyword sets) used only when
  `ConversationInput.intent` is not supplied. It is explicitly *not* a
  statistical/trained model — see the "ML ISOLATION" docstring in
  `app/speech/__init__.py`.
- **Local entity extraction** (`_extract_topic` /
  `_extract_destination`) uses plain regular expressions over common
  English lead-phrases ("where is", "guide me to", ...) plus a filler-
  prefix stripper ("can you", "please", ...) — deterministic, no ML.

## 4. Files added

```
app/speech/__init__.py
app/speech/context.py
app/speech/conversation.py
app/speech/knowledge.py
app/speech/language.py
app/speech/response.py
docs/speech_conversation.md
tests/speech/__init__.py
tests/speech/test_conversation.py
tests/speech/test_isolation.py
tests/speech/test_language.py
PHASE_REPORT.md
speech-conversation-phase.tar.gz
```

## 5. Exact list of existing files modified

**None.** No existing file anywhere in the repository (top-level
`app/`, `tests/`, `docs/`, `README.md`, `requirements.txt`,
`app/config.py`, `app/main.py`, or any protected module) was modified,
renamed, moved, or reformatted. Only new files were added, all listed
in Section 4.

(The nested `ai-university-lab-guide/` directory and the top-level
`*.tar.gz` files were not touched either — they were identified during
the audit as pre-existing, older archive artifacts unrelated to the
current top-level source of truth, and were left exactly as found.)

## 6. Explicit confirmation that no protected module was modified

Confirmed. None of the following were modified in any way:

```
app/vision/    app/robot/    app/ml/    app/dl/
app/navigation/  app/decision/  app/guide/  app/models/
app/main.py    app/config.py
existing shared contracts     existing tests     existing documentation
```

`RobotCommandType` was not modified, extended, or referenced as code
anywhere (statically verified — see Section 9,
`tests/speech/test_isolation.py::TestNoForbiddenImports::
test_no_robot_command_type_reference_anywhere_in_package`, which
parses the AST of every file under `app/speech/` and asserts no
`RobotCommandType`/`RobotCommand` identifier is ever used as code). No
Robot command was added.

## 7. Robot isolation verification

- `app/speech/**/*.py` contains no `import app.robot` /
  `from app.robot import ...` anywhere (statically verified via AST
  parsing in `tests/speech/test_isolation.py`).
- `app/speech` never references `RobotCommandType` or constructs a
  `RobotCommand` (AST-verified, not just a text search — this avoids
  false positives from the module's own docstrings, which *describe*
  the isolation rule in prose).
- A runtime check
  (`TestNoRobotDependencyAtRuntime::
  test_app_robot_not_imported_as_a_side_effect`) clears `app.robot`
  from `sys.modules`, imports `app.speech` fresh, and asserts
  `app.robot` was not pulled back in as a transitive import.
- `ConversationResponse.spoken_text` is plain text only; no speech is
  executed, no hardware/backend is touched.

## 8. ML isolation verification

- `app/speech/**/*.py` contains no `import app.ml` /
  `from app.ml import ...` anywhere (AST-verified).
- A runtime check
  (`TestNoMLDependencyAtRuntime::test_app_ml_not_imported_as_a_side_effect`)
  clears `app.ml` from `sys.modules`, imports `app.speech` fresh, and
  asserts `app.ml` was not pulled back in as a transitive import.
- The module never trains or runs a statistical classifier. Its
  fallback intent inference (`_infer_local_intent`) is plain,
  deterministic keyword matching, documented as such everywhere it
  appears.
- `app.models.schemas.IntentType` (a shared, framework-independent
  enum with zero ML-library dependency) is imported — this is
  explicitly permitted ("The caller may provide detected intent as
  input if an existing architecture supports this") and does not
  import `app.ml` itself.

`app/speech/**/*.py` also contains no `import app.vision`,
`app.dl`, or `app.main` (same AST check covers all four forbidden
modules in one parametrized test).

## 9. Tests added

`tests/speech/` (24 + 20 + 6 = wait, see exact count in Section 11),
covering every category the phase brief requires:

| Requirement | Test(s) |
|---|---|
| Greeting | `TestGreeting` (3 tests) |
| Navigation confirmation | `TestNavigationConfirmation` (2 tests) |
| Information response | `TestInformationResponse` (3 tests) |
| Clarification | `TestClarification` (3 tests) |
| Unknown request | `TestUnknownRequest` (2 tests) |
| Context follow-up | `TestContextFollowUp` (2 tests) |
| Arabic-ready behavior | `TestArabicReadyBehavior` (3 tests) + `TestPhraseTable`/`TestLanguageDetection` in `test_language.py` |
| English behavior | `TestEnglishBehavior` (1 test) + English cases throughout |
| Context reset | `TestContextReset` (3 tests) |
| Malformed input | `TestMalformedInput` (4 tests) |
| Module isolation | `TestNoForbiddenImports`, `TestOfflineDeterministicBehavior` in `test_isolation.py` |
| No Robot dependency | `TestNoRobotDependencyAtRuntime` in `test_isolation.py` |
| No ML dependency | `TestNoMLDependencyAtRuntime` in `test_isolation.py` |
| No network/external API requirement | `TestNoForbiddenImports::test_file_has_no_network_imports` in `test_isolation.py` |

Plus additional tests for initialization, caller-provided
intent/information/destination precedence, and confirmation
acknowledgement (`TestConfirmation`).

All tests are deterministic, offline, hardware-independent, and
network-independent — every scenario is exercised with plain
in-memory `ConversationInput`/`ConversationContext` objects.

## 10. Final full pytest result

**Environment limitation, disclosed honestly:** this sandbox has no
network access, and the `pytest` package (listed in
`requirements.txt` as a project dependency, but not pre-installed in
this execution environment) could not be installed (`pip install
pytest` fails with "No matching distribution found" — no package
index reachable). `python -m pytest -q` could therefore not be
literally executed inside this sandbox.

To still verify correctness without pytest, a small offline
test-collection/execution shim (a `pytest`-lookalike module providing
just `fixture`, `mark.parametrize`, and `raises`, plus a custom
collector) was written **outside the repository** (not part of the
deliverable — not included in the archive) purely so the real test
files in `tests/speech/` (written in ordinary, unmodified pytest
syntax — `@pytest.fixture`, `@pytest.mark.parametrize`, plain
`assert`) could be executed as-is in this sandbox:

```
tests.speech.test_language:     10 passed, 0 failed
tests.speech.test_conversation: 33 passed, 0 failed
tests.speech.test_isolation:     6 passed, 0 failed
TOTAL: 49 passed, 0 failed
```

No existing file was modified during this verification, and the shim
only ever imported `app.speech` and `app.models.schemas` — it never
touched `app.robot`, `app.ml`, `app.vision`, `app.dl`, or `app.main`.

**In any environment with `pytest` actually installed** (i.e. a normal
`pip install -r requirements.txt`), `python -m pytest -q` should be
run directly against the full suite (`tests/` including the new
`tests/speech/` subdirectory) to get the canonical result; nothing
about these tests depends on the shim, which was strictly a
sandbox-verification convenience.

## 11. Final test count

**49 new tests added** in `tests/speech/`
(`test_conversation.py`: 33, `test_language.py`: 10,
`test_isolation.py`: 6), all passing under the verification described
in Section 10. Zero existing tests were modified, so the project's
pre-existing test count is unaffected.

## 12. Integration gaps discovered, if any

See `docs/speech_conversation.md`, "Integration gaps discovered" for
full detail. Summary:

1. No orchestrator yet calls `app.ml.service.MLIntentService.predict()`
   and feeds the result into `ConversationInput.intent` — that wiring
   is a future `app.main` integration phase's job, explicitly out of
   scope here (`app.main` is protected).
2. No orchestrator yet calls `GuideService.get_topic_content()` /  a
   Navigation service and feeds `spoken_text`/route info into
   `ConversationInput.information_text` / `destination` — same reason.
   `app.navigation` itself is also still unimplemented (scaffolded
   only), so there is nothing to integrate with yet regardless.
3. A small, explicitly-labeled placeholder local knowledge table
   (`app/speech/knowledge.py`) was added so the module's own worked
   example works standalone, pending real Guide/Navigation wiring.
4. `IntentType.COMBINED` (from `app.models.schemas`) is currently
   mapped to NAVIGATION-priority handling, since this phase handles
   one intent per conversational turn.

None of these required touching any protected module.

## 13. Limitations, if any

- Local (non-ML) intent inference and entity extraction are
  keyword/regex-based and English/Arabic-keyword-aware, not a full
  NLU system — by design, per the phase brief ("Do NOT create a
  complicated LLM framework").
- The placeholder knowledge table (`knowledge.py`) covers only four
  illustrative locations and is explicitly not meant to be a
  permanent or complete content source (see Section 12, item 3).
- `pytest` itself could not be executed in this sandbox (no network
  to install it) — see Section 10 for exactly how correctness was
  verified instead, and what to run in a normal environment.
- Malformed non-text input (e.g. `int`, `None`) is handled gracefully
  for `ConversationInput.text`, but this module assumes
  `ConversationInput` itself is well-formed (a Python dataclass
  instance) — it does not attempt to validate against, say, raw JSON
  from an untrusted network boundary, since no such boundary exists
  in this module's scope.

## 14. Archive validation result

`speech-conversation-phase.tar.gz` was built from a clean, `__pycache__`
-free copy of only the phase deliverables and validated by extracting
it into an empty directory and listing its full contents (see below,
Section reproduced by the extraction command run as part of this
phase). It contains **only**:

```
app/speech/__init__.py
app/speech/context.py
app/speech/conversation.py
app/speech/knowledge.py
app/speech/language.py
app/speech/response.py
docs/speech_conversation.md
tests/speech/__init__.py
tests/speech/test_conversation.py
tests/speech/test_isolation.py
tests/speech/test_language.py
PHASE_REPORT.md
```

No `.git/`, no virtual environment, no cache, no unrelated
application module, and no protected module is present in the
archive.
