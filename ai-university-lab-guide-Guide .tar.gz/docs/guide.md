# Guide — University Information Service

Owner: Person 1 (AI / Intelligence).

> **Note on this phase:** the Guide module (`app/guide/`) already
> existed, fully implemented and integrated into `app/main.py`, before
> this phase began — see "A note on scope" below for what this phase
> actually changed and why.

## 1. Purpose

Given a topic identifier, return structured, spoken-text-ready
information about a university location or facility. Nothing more.

Guide answers: **"WHAT is the place?"**, **"WHAT is it used for?"**
Navigation answers: **"WHERE is the place?"**

## 2. Architecture

```
topic (GuideTopic)
      |
      v
GuideService.get_topic_content()   (app.guide.guide_service)
      |
      v
GuideResponse                       (app.guide.guide_service)
```

Internally, `GuideService` looks up static content from
`app.guide.content.TOPIC_CONTENT`.

### Package layout

```
app/guide/
├── __init__.py          re-exports GuideResponse, GuideService
├── content.py             static topic content (TopicContent, TOPIC_CONTENT)
└── guide_service.py        GuideResponse contract + GuideService
```

## 3. Guide responsibilities

Guide is responsible for:
- storing university information, keyed by topic
- retrieving information by topic
- returning a structured, deterministic response
- providing text suitable for future robot speech (`spoken_text`)
- handling unknown topics safely (never crashing)

Guide is **not** responsible for: understanding natural language,
intent classification, route calculation, robot movement/speech,
gesture recognition, or final decision-making.

## 4. Navigation vs Guide boundary

| Question | Module |
|---|---|
| "Where is the AI Lab?" | Navigation |
| "What is the AI Lab?" | Guide |
| "What do students do in the AI Lab?" | Guide |

Guide does **not** import `app.navigation`, and does not calculate or
know about routes. This boundary is enforced by
`scripts/check_guide_dependencies.py` and
`tests/guide/test_dependencies.py`.

### The Decision exception (read this)

This phase's instructions state a blanket rule: *"Guide MUST NOT
import app.decision."* The **existing**, already-integrated Guide
module (part of the Phase 7 baseline, predating this phase, and
already wired into `app/main.py`) imports exactly **one** symbol from
Decision: `app.decision.event_manager.GuideTopic` — a plain, stable
topic-identifier `Enum`, not application behavior. It explicitly does
**not** import `app.decision.state_manager` (Decision's state
machine), and this repository already has a passing test asserting
that (`tests/test_guide.py::TestGuideIndependence::
test_guide_does_not_import_decision_state_manager`), plus the existing
`docs/integration_contract.md` already documents this exact boundary:

```
Guide → Config, Logger, (single symbol: app.decision.event_manager.GuideTopic)
Guide → app.decision.state_manager (never — Guide never depends on Decision's state machine)
```

This phase preserved that existing, tested, documented exception
rather than removing it, per this project's own overriding rules:
*"the uploaded ZIP is the source of truth,"* *"do NOT redesign the
existing architecture,"* and *"the existing Phase 7 integration must
remain intact."* Removing the `GuideTopic` import would have required
either (a) duplicating `GuideTopic` as a second, competing topic
enum — explicitly forbidden ("if a suitable contract exists, use it,
do not create a duplicate") — or (b) breaking `app/main.py`'s live,
protected integration, which imports and calls `GuideService` directly
(`app/main.py` lines ~35, ~104–110). Both outcomes were judged worse
than documenting the conflict here.

`scripts/check_guide_dependencies.py` and
`tests/guide/test_dependencies.py` enforce this precise boundary:
`GuideTopic` from `app.decision.event_manager` is allowed; nothing else
from `app.decision` is.

## 5. Data structure

`app/guide/content.py` defines:

```python
@dataclass(frozen=True)
class TopicContent:
    title: str
    summary: str
    sections: List[str]
    spoken_text: str

TOPIC_CONTENT: Dict[GuideTopic, TopicContent] = { ... }
```

Content is intentionally **generic, demonstration content** — it does
not claim specific institutional facts (no invented room numbers,
phone numbers, staff names, or opening hours). This was already true
of the existing content and remains unchanged.

## 6. Available topics

Guide reuses the existing `GuideTopic` enum
(`app.decision.event_manager.GuideTopic`) as its topic vocabulary,
rather than introducing a second one:

| Topic | Covers |
|---|---|
| `AI_PROJECTS` | AI projects developed/studied in the lab |
| `ROBOTICS` | Robotics work: perception, control, physical interaction |
| `TRAINING` | Training & learning opportunities |
| `LAB_INFORMATION` | General information about the lab |

No new topics were added in this phase (the map/topic set introduced
by `app.navigation` — `MAIN_GATE`, `LIBRARY`, etc. — is a separate,
unrelated identifier space; Guide's topics and Navigation's locations
are intentionally not unified, since Guide answers "what" and
Navigation answers "where" for a different kind of request).

## 7. `GuideResponse` contract

Defined in `app/guide/guide_service.py` (**not** `app/models/schemas.py`
— see below for why):

```python
@dataclass(frozen=True)
class GuideResponse:
    topic: Optional[GuideTopic]
    title: str
    summary: str
    sections: List[str] = field(default_factory=list)
    spoken_text: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
```

**Why `GuideResponse` was not moved to `app.models.schemas`:** a
suitable contract already existed before this phase, so per this
phase's own rule ("if it exists, use it — do not create a duplicate"),
it was left as-is. Moving it would also introduce an
`app.models → app.decision` dependency (since `GuideResponse.topic` is
typed as `GuideTopic`), which conflicts with `app/models/schemas.py`'s
own existing, documented invariant of having **zero** app-internal
imports (already relied upon by `IntentResult`, `GestureResult`, and
`NavigationResult`, all of which are self-contained). Keeping
`GuideResponse` in `app.guide` avoids that conflict entirely — the same
reasoning already recorded in the existing code's own docstring.

**Unknown-topic convention:** rather than a `success: bool` field,
the existing contract signals an unavailable topic via
`topic=None` plus a fixed `title="Topic Unavailable"` /
`summary="This topic is not currently available."`, with empty
`sections`. This is an already-established, already-tested convention
and was preserved rather than changed to a boolean-flag shape.

## 8. Public API

```python
from app.guide import GuideService
from app.decision.event_manager import GuideTopic

service = GuideService()
response = service.get_topic_content(GuideTopic.AI_PROJECTS)
print(response.spoken_text)
```

`GuideService` has exactly one public method: `get_topic_content(topic)
-> GuideResponse`. Callers never need to know about the internal
`TOPIC_CONTENT` dict or lookup logic.

## 9. Unknown-topic behavior

`get_topic_content` never raises for invalid input. Any value that
isn't a valid `GuideTopic` member — `None`, a string, a number, an
unrecognized enum-like value — returns:

```python
GuideResponse(
    topic=None,
    title="Topic Unavailable",
    summary="This topic is not currently available.",
    sections=[],
    spoken_text="This topic is not currently available.",
)
```

## 10. Testing

```bash
# Existing Guide tests (pre-existing, part of the protected baseline)
pytest tests/test_guide.py -v

# New supplementary tests added this phase
pytest tests/guide/ -v

# Full suite
pytest -v
```

`tests/test_guide.py` (pre-existing, unchanged) covers: per-topic
content retrieval, unknown/`None`/invalid-type topic handling,
`GuideResponse` shape, and independence from Robot/Vision/Decision's
state machine.

`tests/guide/` (new, added this phase) adds: a comprehensive AST-based
check against every module forbidden specifically by P1-GUIDE
(`app.ml`, `app.dl`, `app.navigation`, in addition to the
already-tested `app.robot`/`app.vision`), an explicit check that the
only `app.decision` import is `GuideTopic`, determinism checks
(repeated calls / fresh instances return equal content), cross-topic
data-integrity checks (no duplicate titles/spoken_text, no empty
fields, reasonably concise `spoken_text`), and a public-API-surface
check (`GuideService` exposes exactly one public method).

All tests run with no camera, Robot, Robot SDK, ML, DL, Vision,
Decision state machine, Navigation, UI, or network dependency.

## 11. How to add a new topic

1. Add the new member to `GuideTopic` in
   `app/decision/event_manager.py` — **this file is owned by Decision,
   not Guide**; adding a topic there is a Decision-layer change and
   outside this phase's scope. (This phase only documents the
   procedure; it does not modify `app/decision/`.)
2. Add a `TopicContent` entry to `TOPIC_CONTENT` in
   `app/guide/content.py`, following the existing four topics'
   generic-demo-content style — no invented institutional facts.
3. Re-run `pytest tests/test_guide.py tests/guide/` to confirm
   `test_all_guide_topics_have_registered_content` (and the new
   `test_every_guide_topic_has_content`) still pass.

## 12. Future integration point

Guide is already integrated into `app/main.py` (part of the pre-existing
Phase 7 baseline — not new in this phase):

```
Camera → Vision → Decision → main.py → Guide → main.py → Robot Controller → Robot Speech + Gestures
```

The future, not-yet-implemented combined flow this phase does **not**
add:

```
Student Question
      ↓
     ML
      ↓
  IntentResult
      ↓
   Decision
      ↙       ↘
Guide       Navigation
  ↓              ↓
GuideResponse  NavigationResult
```

**P1-Guide does not integrate with:** ML, DL, Vision, Navigation, or
Robot beyond what was already true of the existing baseline; and this
phase did not modify Decision, Robot, UI, or `main.py`.
