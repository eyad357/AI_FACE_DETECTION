"""Test package for app.navigation -- the university navigation module."""
