"""Tests for app.navigation.pathfinder -- the shortest-path algorithm."""

from __future__ import annotations

from app.navigation.map_data import build_adjacency
from app.navigation.pathfinder import find_shortest_path


class TestFindShortestPath:
    def test_direct_route(self):
        adjacency = build_adjacency()
        result = find_shortest_path(adjacency, "AI_LAB", "ROBOTICS_LAB")
        assert result is not None
        route, distance = result
        assert route == ["AI_LAB", "ROBOTICS_LAB"]
        assert distance == 40.0

    def test_multi_step_route(self):
        adjacency = build_adjacency()
        result = find_shortest_path(adjacency, "MAIN_GATE", "ROBOTICS_LAB")
        assert result is not None
        route, distance = result
        assert route == [
            "MAIN_GATE",
            "ADMINISTRATION",
            "COMPUTER_BUILDING",
            "AI_LAB",
            "ROBOTICS_LAB",
        ]
        assert distance == 310.0

    def test_alternative_route_selection_picks_shortest(self):
        # MAIN_GATE -> AI_LAB is reachable via ADMINISTRATION (270) or
        # via LIBRARY (290); the shorter one must be chosen.
        adjacency = build_adjacency()
        result = find_shortest_path(adjacency, "MAIN_GATE", "AI_LAB")
        assert result is not None
        route, distance = result
        assert route == ["MAIN_GATE", "ADMINISTRATION", "COMPUTER_BUILDING", "AI_LAB"]
        assert distance == 270.0

    def test_origin_equals_destination(self):
        adjacency = build_adjacency()
        result = find_shortest_path(adjacency, "MAIN_GATE", "MAIN_GATE")
        assert result == (["MAIN_GATE"], 0.0)

    def test_unreachable_destination_returns_none(self):
        adjacency = build_adjacency()
        result = find_shortest_path(adjacency, "MAIN_GATE", "OLD_ANNEX")
        assert result is None

    def test_unreachable_is_symmetric(self):
        adjacency = build_adjacency()
        result = find_shortest_path(adjacency, "OLD_ANNEX", "MAIN_GATE")
        assert result is None

    def test_route_starts_at_origin(self):
        adjacency = build_adjacency()
        route, _ = find_shortest_path(adjacency, "LECTURE_HALL_B", "CAFETERIA")
        assert route[0] == "LECTURE_HALL_B"

    def test_route_ends_at_destination(self):
        adjacency = build_adjacency()
        route, _ = find_shortest_path(adjacency, "LECTURE_HALL_B", "CAFETERIA")
        assert route[-1] == "CAFETERIA"

    def test_route_contains_only_valid_nodes(self):
        from app.navigation.map_data import LOCATIONS

        adjacency = build_adjacency()
        route, _ = find_shortest_path(adjacency, "MAIN_GATE", "STUDENT_AFFAIRS")
        assert all(node in LOCATIONS for node in route)

    def test_route_has_no_accidental_cycles(self):
        adjacency = build_adjacency()
        route, _ = find_shortest_path(adjacency, "MAIN_GATE", "STUDENT_AFFAIRS")
        assert len(route) == len(set(route))

    def test_deterministic_output(self):
        adjacency = build_adjacency()
        first = find_shortest_path(adjacency, "MAIN_GATE", "STUDENT_AFFAIRS")
        second = find_shortest_path(adjacency, "MAIN_GATE", "STUDENT_AFFAIRS")
        assert first == second

    def test_distance_calculation_matches_sum_of_edges(self):
        adjacency = build_adjacency()
        route, distance = find_shortest_path(adjacency, "MAIN_GATE", "AI_LAB")
        expected = sum(
            adjacency[route[i]][route[i + 1]] for i in range(len(route) - 1)
        )
        assert distance == expected
