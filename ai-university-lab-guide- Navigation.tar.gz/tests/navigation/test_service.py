"""Tests for app.navigation.service -- the public Navigation API."""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

from app.models.schemas import NavigationResult
from app.navigation.service import NavigationService


@pytest.fixture(scope="module")
def navigation() -> NavigationService:
    return NavigationService()


class TestValidRoutes:
    def test_valid_direct_route(self, navigation):
        result = navigation.find_route("AI_LAB", "ROBOTICS_LAB")
        assert result.success is True
        assert result.route == ["AI_LAB", "ROBOTICS_LAB"]
        assert result.distance == 40.0

    def test_valid_multi_step_route(self, navigation):
        result = navigation.find_route("MAIN_GATE", "ROBOTICS_LAB")
        assert result.success is True
        assert len(result.route) > 2
        assert result.route[0] == "MAIN_GATE"
        assert result.route[-1] == "ROBOTICS_LAB"

    def test_alternative_route_selection(self, navigation):
        # Two paths exist from MAIN_GATE to AI_LAB; the cheaper one
        # (via ADMINISTRATION, 270) must be selected over the longer
        # one (via LIBRARY, 290).
        result = navigation.find_route("MAIN_GATE", "AI_LAB")
        assert result.success is True
        assert "ADMINISTRATION" in result.route
        assert result.distance == 270.0

    def test_origin_equals_destination(self, navigation):
        result = navigation.find_route("MAIN_GATE", "MAIN_GATE")
        assert result.success is True
        assert result.route == ["MAIN_GATE"]
        assert result.distance == 0.0


class TestInvalidLocations:
    def test_unknown_origin(self, navigation):
        result = navigation.find_route("NOT_A_PLACE", "AI_LAB")
        assert result.success is False
        assert result.route == []
        assert result.error is not None

    def test_unknown_destination(self, navigation):
        result = navigation.find_route("MAIN_GATE", "NOT_A_PLACE")
        assert result.success is False
        assert result.error is not None

    def test_unreachable_destination(self, navigation):
        result = navigation.find_route("MAIN_GATE", "OLD_ANNEX")
        assert result.success is False
        assert result.route == []
        assert result.distance is None
        assert "unreachable" in result.error.lower() or "no route" in result.error.lower()

    def test_does_not_crash_on_none_input(self, navigation):
        result = navigation.find_route(None, "AI_LAB")  # type: ignore[arg-type]
        assert result.success is False


class TestRouteProperties:
    def test_route_starts_at_origin(self, navigation):
        result = navigation.find_route("MAIN_GATE", "STUDENT_AFFAIRS")
        assert result.route[0] == result.origin

    def test_route_ends_at_destination(self, navigation):
        result = navigation.find_route("MAIN_GATE", "STUDENT_AFFAIRS")
        assert result.route[-1] == result.destination

    def test_route_has_no_duplicate_nodes(self, navigation):
        result = navigation.find_route("MAIN_GATE", "STUDENT_AFFAIRS")
        assert len(result.route) == len(set(result.route))

    def test_case_and_whitespace_insensitive_lookup(self, navigation):
        result = navigation.find_route("  main_gate ", "ai_lab")
        assert result.success is True
        assert result.origin == "MAIN_GATE"
        assert result.destination == "AI_LAB"


class TestDeterminism:
    def test_repeated_calls_are_deterministic(self, navigation):
        first = navigation.find_route("MAIN_GATE", "STUDENT_AFFAIRS")
        second = navigation.find_route("MAIN_GATE", "STUDENT_AFFAIRS")
        assert first == second

    def test_new_service_instance_gives_same_result(self):
        a = NavigationService().find_route("MAIN_GATE", "AI_LAB")
        b = NavigationService().find_route("MAIN_GATE", "AI_LAB")
        assert a == b


class TestNavigationResultContract:
    def test_result_is_navigation_result(self, navigation):
        result = navigation.find_route("MAIN_GATE", "AI_LAB")
        assert isinstance(result, NavigationResult)

    def test_success_result_requires_matching_route_bounds(self):
        with pytest.raises(ValueError):
            NavigationResult(
                success=True,
                origin="A",
                destination="B",
                route=["A", "C", "X"],  # does not end at "B"
            )

    def test_success_result_requires_non_empty_route(self):
        with pytest.raises(ValueError):
            NavigationResult(success=True, origin="A", destination="B", route=[])

    def test_failure_result_requires_error(self):
        with pytest.raises(ValueError):
            NavigationResult(success=False, origin="A", destination="B", error=None)

    def test_negative_distance_rejected(self):
        with pytest.raises(ValueError):
            NavigationResult(
                success=True,
                origin="A",
                destination="A",
                route=["A"],
                distance=-1.0,
            )

    def test_result_is_frozen(self):
        result = NavigationResult(
            success=True, origin="A", destination="A", route=["A"], distance=0.0
        )
        with pytest.raises(Exception):
            result.success = False  # type: ignore[misc]


class TestPublicServiceAPI:
    def test_find_route_is_the_only_public_entry_point(self):
        public_methods = [
            name
            for name in dir(NavigationService)
            if not name.startswith("_") and callable(getattr(NavigationService, name))
        ]
        assert public_methods == ["find_route"]

    def test_service_reusable_across_calls(self, navigation):
        # A single instance should answer multiple independent queries.
        r1 = navigation.find_route("MAIN_GATE", "AI_LAB")
        r2 = navigation.find_route("LIBRARY", "CAFETERIA")
        assert r1.success is True
        assert r2.success is True


class TestNoForbiddenDependencies:
    """
    Static (AST-based) checks that app.navigation does not import ML,
    DL, Vision, Robot, Decision, Guide, UI, or main -- independent of
    scripts/check_navigation_dependencies.py, as a fast in-suite
    guardrail.
    """

    NAV_DIR = Path(__file__).resolve().parent.parent.parent / "app" / "navigation"
    FORBIDDEN_ROOTS = (
        "app.ml",
        "app.dl",
        "app.vision",
        "app.robot",
        "app.decision",
        "app.guide",
        "app.ui",
        "app.main",
    )

    def _imports_in_file(self, path: Path) -> list[str]:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                modules.append(node.module)
        return modules

    def test_no_forbidden_imports_anywhere_in_app_navigation(self):
        violations = []
        for py_file in sorted(self.NAV_DIR.rglob("*.py")):
            for module in self._imports_in_file(py_file):
                for forbidden in self.FORBIDDEN_ROOTS:
                    if module == forbidden or module.startswith(forbidden + "."):
                        violations.append(f"{py_file.name}: imports {module!r}")
        assert violations == []
