"""Tests for app.navigation.map_data -- the static university map."""

from __future__ import annotations

from app.navigation.map_data import (
    AI_LAB,
    LOCATIONS,
    MAIN_GATE,
    OLD_ANNEX,
    build_adjacency,
    is_known_location,
)


class TestLocations:
    def test_locations_non_empty(self):
        assert len(LOCATIONS) > 0

    def test_locations_are_unique(self):
        assert len(LOCATIONS) == len(set(LOCATIONS))

    def test_locations_are_strings(self):
        assert all(isinstance(loc, str) for loc in LOCATIONS)

    def test_map_has_enough_locations_to_be_realistic(self):
        # Enough to demonstrate direct/multi-step/alternative routes,
        # without being an inflated fake campus.
        assert 5 <= len(LOCATIONS) <= 20


class TestIsKnownLocation:
    def test_known_location_returns_true(self):
        assert is_known_location(MAIN_GATE) is True
        assert is_known_location(AI_LAB) is True

    def test_unknown_location_returns_false(self):
        assert is_known_location("NOT_A_REAL_PLACE") is False

    def test_empty_string_returns_false(self):
        assert is_known_location("") is False


class TestAdjacency:
    def test_adjacency_has_all_locations_as_keys(self):
        adjacency = build_adjacency()
        assert set(adjacency.keys()) == set(LOCATIONS)

    def test_adjacency_is_symmetric(self):
        # Edges are undirected: if A -> B exists with distance d,
        # B -> A must exist with the same distance.
        adjacency = build_adjacency()
        for a, neighbors in adjacency.items():
            for b, distance in neighbors.items():
                assert a in adjacency[b]
                assert adjacency[b][a] == distance

    def test_edge_distances_are_positive(self):
        adjacency = build_adjacency()
        for neighbors in adjacency.values():
            for distance in neighbors.values():
                assert distance > 0

    def test_old_annex_is_intentionally_disconnected(self):
        # Used to exercise unreachable-destination handling.
        adjacency = build_adjacency()
        assert adjacency[OLD_ANNEX] == {}

    def test_map_has_at_least_one_alternative_path(self):
        # MAIN_GATE -> AI_LAB is reachable via more than one route
        # (through ADMINISTRATION or through LIBRARY), which is what
        # makes alternative-route-selection testing meaningful.
        adjacency = build_adjacency()
        assert "ADMINISTRATION" in adjacency[MAIN_GATE]
        assert "LIBRARY" in adjacency[MAIN_GATE]
