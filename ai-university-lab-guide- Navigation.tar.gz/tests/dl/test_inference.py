"""Tests for app.dl.inference.inference -- runtime inference."""

from __future__ import annotations

import pytest

from app.dl.dataset import _TEMPLATES, _template_to_landmarks
from app.dl.inference.inference import (
    ArtifactNotFoundError,
    DEFAULT_ARTIFACT_PATH,
    clear_cache,
    load_pipeline,
    predict_gesture,
)
from app.dl.training.train import train


class TestMissingArtifact:
    def test_load_pipeline_missing_raises(self, tmp_path):
        missing = tmp_path / "nope.joblib"
        with pytest.raises(ArtifactNotFoundError):
            load_pipeline(missing)

    def test_predict_gesture_missing_artifact_raises(self, tmp_path):
        missing = tmp_path / "nope.joblib"
        with pytest.raises(ArtifactNotFoundError):
            predict_gesture([0.5] * 42, artifact_path=missing)

    def test_missing_artifact_error_is_clear(self, tmp_path):
        missing = tmp_path / "nope.joblib"
        with pytest.raises(ArtifactNotFoundError, match="training"):
            load_pipeline(missing)


class TestArtifactLoadingAndInference:
    def test_default_artifact_exists(self):
        # The trained artifact is committed to app/dl/artifacts/ so
        # runtime inference never needs to train.
        assert DEFAULT_ARTIFACT_PATH.exists()

    def test_load_pipeline_from_default_artifact(self):
        clear_cache()
        pipeline = load_pipeline(DEFAULT_ARTIFACT_PATH)
        assert pipeline is not None
        assert hasattr(pipeline, "predict")

    def test_predict_gesture_returns_label_and_confidence(self):
        clear_cache()
        landmarks = _template_to_landmarks(_TEMPLATES["STOP"])
        label, confidence = predict_gesture(
            landmarks, artifact_path=DEFAULT_ARTIFACT_PATH
        )
        assert isinstance(label, str)
        assert 0.0 <= confidence <= 1.0

    def test_pipeline_is_cached_between_calls(self):
        clear_cache()
        first = load_pipeline(DEFAULT_ARTIFACT_PATH)
        second = load_pipeline(DEFAULT_ARTIFACT_PATH)
        assert first is second


class TestInferenceDoesNotRetrain:
    def test_predict_with_trained_artifact_does_not_touch_dataset(self, tmp_path):
        artifact_path = tmp_path / "isolated.joblib"
        train(samples_per_class=15, artifact_path=artifact_path)

        clear_cache()
        landmarks = _template_to_landmarks(_TEMPLATES["POINT"])
        label, confidence = predict_gesture(landmarks, artifact_path=artifact_path)
        assert isinstance(label, str)
        assert 0.0 <= confidence <= 1.0


class TestModelPersistence:
    def test_trained_artifact_round_trips_predictions(self, tmp_path):
        artifact_path = tmp_path / "roundtrip.joblib"
        train(samples_per_class=15, artifact_path=artifact_path)

        clear_cache()
        landmarks = _template_to_landmarks(_TEMPLATES["WAVE"])
        label_a, confidence_a = predict_gesture(landmarks, artifact_path=artifact_path)

        clear_cache()  # force a fresh load from disk
        label_b, confidence_b = predict_gesture(landmarks, artifact_path=artifact_path)

        assert label_a == label_b
        assert confidence_a == confidence_b
