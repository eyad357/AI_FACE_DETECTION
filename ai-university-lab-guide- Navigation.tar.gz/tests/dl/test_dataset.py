"""Tests for app.dl.models.landmark_schema and app.dl.dataset."""

from __future__ import annotations

import pytest

from app.dl.dataset import generate_dataset
from app.dl.models.landmark_schema import (
    LandmarkValidationError,
    NUM_FEATURES,
    NUM_LANDMARKS,
    validate_landmarks,
)
from app.models.schemas import GestureType


class TestLandmarkSchema:
    def test_num_features_matches_landmarks_times_two(self):
        assert NUM_FEATURES == NUM_LANDMARKS * 2

    def test_valid_landmarks_pass(self):
        validate_landmarks([0.5] * NUM_FEATURES)  # should not raise

    def test_none_raises(self):
        with pytest.raises(LandmarkValidationError):
            validate_landmarks(None)

    def test_string_raises(self):
        with pytest.raises(LandmarkValidationError):
            validate_landmarks("not a sequence")

    def test_non_iterable_raises(self):
        with pytest.raises(LandmarkValidationError):
            validate_landmarks(12345)

    def test_wrong_length_too_short_raises(self):
        with pytest.raises(LandmarkValidationError):
            validate_landmarks([0.5] * 10)

    def test_wrong_length_too_long_raises(self):
        with pytest.raises(LandmarkValidationError):
            validate_landmarks([0.5] * (NUM_FEATURES + 5))

    def test_non_numeric_value_raises(self):
        values = [0.5] * NUM_FEATURES
        values[3] = "oops"
        with pytest.raises(LandmarkValidationError):
            validate_landmarks(values)

    def test_bool_value_raises(self):
        values = [0.5] * NUM_FEATURES
        values[0] = True
        with pytest.raises(LandmarkValidationError):
            validate_landmarks(values)

    def test_out_of_range_value_raises(self):
        values = [0.5] * NUM_FEATURES
        values[0] = 1.5
        with pytest.raises(LandmarkValidationError):
            validate_landmarks(values)

        values[0] = -0.1
        with pytest.raises(LandmarkValidationError):
            validate_landmarks(values)


class TestSyntheticDataset:
    def test_generate_dataset_default_size(self):
        examples = generate_dataset()
        assert len(examples) == 3 * 40  # 3 classes * default samples_per_class

    def test_generate_dataset_custom_size(self):
        examples = generate_dataset(samples_per_class=5)
        assert len(examples) == 15

    def test_all_labeled_gestures_represented(self):
        examples = generate_dataset(samples_per_class=5)
        labels = {e[1] for e in examples}
        expected = {
            name for name in GestureType.__members__ if name != GestureType.UNKNOWN.name
        }
        assert labels == expected

    def test_each_landmark_vector_has_correct_length(self):
        examples = generate_dataset(samples_per_class=3)
        for landmarks, _ in examples:
            assert len(landmarks) == NUM_FEATURES

    def test_each_landmark_vector_is_valid(self):
        examples = generate_dataset(samples_per_class=3)
        for landmarks, _ in examples:
            validate_landmarks(landmarks)  # should not raise

    def test_generation_is_deterministic(self):
        a = generate_dataset(samples_per_class=5, seed=7)
        b = generate_dataset(samples_per_class=5, seed=7)
        assert a == b

    def test_different_seeds_produce_different_noise(self):
        a = generate_dataset(samples_per_class=5, seed=1)
        b = generate_dataset(samples_per_class=5, seed=2)
        assert a != b
