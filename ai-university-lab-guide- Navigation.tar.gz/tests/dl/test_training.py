"""Tests for app.dl.training.train -- the offline training pipeline."""

from __future__ import annotations

import pytest

from app.dl.training.train import DLTrainingResult, train


class TestDLTrainingPipeline:
    def test_train_produces_result(self, tmp_path):
        artifact_path = tmp_path / "test_gesture_classifier.joblib"
        result = train(samples_per_class=15, artifact_path=artifact_path)
        assert isinstance(result, DLTrainingResult)

    def test_train_writes_artifact_file(self, tmp_path):
        artifact_path = tmp_path / "test_gesture_classifier.joblib"
        train(samples_per_class=15, artifact_path=artifact_path)
        assert artifact_path.exists()
        assert artifact_path.stat().st_size > 0

    def test_train_reports_high_accuracy(self, tmp_path):
        # The synthetic templates are cleanly separable by design, so a
        # well-trained model should classify the held-out split well.
        artifact_path = tmp_path / "test_gesture_classifier.joblib"
        result = train(samples_per_class=15, artifact_path=artifact_path)
        assert result.accuracy > 0.8

    def test_train_split_sizes_sum_to_dataset_size(self, tmp_path):
        artifact_path = tmp_path / "test_gesture_classifier.joblib"
        result = train(samples_per_class=15, artifact_path=artifact_path)
        assert result.train_size + result.test_size == 15 * 3

    def test_train_raises_on_too_small_class(self, tmp_path, monkeypatch):
        import app.dl.training.train as train_module

        def fake_dataset(samples_per_class=40, seed=42):
            return [([0.5] * 42, "STOP")]  # only 1 example total

        monkeypatch.setattr(train_module, "generate_dataset", fake_dataset)
        artifact_path = tmp_path / "unused.joblib"
        with pytest.raises(ValueError):
            train(artifact_path=artifact_path)

    def test_training_is_deterministic(self, tmp_path):
        artifact_a = tmp_path / "a.joblib"
        artifact_b = tmp_path / "b.joblib"
        result_a = train(samples_per_class=15, artifact_path=artifact_a)
        result_b = train(samples_per_class=15, artifact_path=artifact_b)
        assert result_a.accuracy == result_b.accuracy
        assert result_a.train_size == result_b.train_size
