"""Test package for app.dl -- the DL gesture recognition module."""
