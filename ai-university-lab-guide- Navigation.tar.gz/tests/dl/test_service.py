"""Tests for app.dl.service -- the public DL gesture recognition API."""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

from app.dl.dataset import _TEMPLATES, _template_to_landmarks
from app.dl.inference.inference import ArtifactNotFoundError
from app.dl.service import GestureRecognitionService
from app.models.schemas import GestureResult, GestureType


@pytest.fixture(scope="module")
def service() -> GestureRecognitionService:
    return GestureRecognitionService()


class TestGestureClassification:
    """
    Uses the clean (noise-free) geometric templates the model was
    trained around, so results are deterministic.
    """

    def test_wave_classification(self, service):
        landmarks = _template_to_landmarks(_TEMPLATES["WAVE"])
        result = service.recognize(landmarks)
        assert result.gesture == GestureType.WAVE

    def test_stop_classification(self, service):
        landmarks = _template_to_landmarks(_TEMPLATES["STOP"])
        result = service.recognize(landmarks)
        assert result.gesture == GestureType.STOP

    def test_point_classification(self, service):
        landmarks = _template_to_landmarks(_TEMPLATES["POINT"])
        result = service.recognize(landmarks)
        assert result.gesture == GestureType.POINT


class TestInputHandling:
    def test_none_returns_unknown(self, service):
        result = service.recognize(None)
        assert result.gesture == GestureType.UNKNOWN
        assert result.confidence == 0.0

    def test_empty_list_returns_unknown(self, service):
        result = service.recognize([])
        assert result.gesture == GestureType.UNKNOWN
        assert result.confidence == 0.0

    def test_wrong_length_returns_unknown(self, service):
        result = service.recognize([0.5] * 10)
        assert result.gesture == GestureType.UNKNOWN

    def test_out_of_range_values_return_unknown(self, service):
        result = service.recognize([1.5] * 42)
        assert result.gesture == GestureType.UNKNOWN

    def test_non_sequence_input_returns_unknown(self, service):
        result = service.recognize("not a sequence")
        assert result.gesture == GestureType.UNKNOWN


class TestConfidenceHandling:
    @pytest.mark.parametrize(
        "gesture_name", ["WAVE", "STOP", "POINT"]
    )
    def test_confidence_within_bounds(self, service, gesture_name):
        landmarks = _template_to_landmarks(_TEMPLATES[gesture_name])
        result = service.recognize(landmarks)
        assert 0.0 <= result.confidence <= 1.0


class TestResultContract:
    def test_result_is_gesture_result(self, service):
        landmarks = _template_to_landmarks(_TEMPLATES["STOP"])
        result = service.recognize(landmarks)
        assert isinstance(result, GestureResult)

    def test_gesture_result_rejects_bad_gesture_type(self):
        from datetime import datetime, timezone

        with pytest.raises(ValueError):
            GestureResult(
                gesture="STOP", confidence=0.5, timestamp=datetime.now(timezone.utc)
            )

    def test_gesture_result_rejects_out_of_range_confidence(self):
        from datetime import datetime, timezone

        with pytest.raises(ValueError):
            GestureResult(
                gesture=GestureType.STOP,
                confidence=1.5,
                timestamp=datetime.now(timezone.utc),
            )
        with pytest.raises(ValueError):
            GestureResult(
                gesture=GestureType.STOP,
                confidence=-0.1,
                timestamp=datetime.now(timezone.utc),
            )

    def test_gesture_result_rejects_bad_timestamp(self):
        with pytest.raises(ValueError):
            GestureResult(gesture=GestureType.STOP, confidence=0.5, timestamp="now")

    def test_gesture_result_is_frozen(self):
        from datetime import datetime, timezone

        result = GestureResult(
            gesture=GestureType.WAVE, confidence=0.9, timestamp=datetime.now(timezone.utc)
        )
        with pytest.raises(Exception):
            result.confidence = 0.1  # type: ignore[misc]


class TestMissingArtifactBehavior:
    def test_missing_artifact_raises_clear_error(self, tmp_path):
        service = GestureRecognitionService(artifact_path=tmp_path / "missing.joblib")
        landmarks = _template_to_landmarks(_TEMPLATES["STOP"])
        with pytest.raises(ArtifactNotFoundError):
            service.recognize(landmarks)

    def test_missing_artifact_does_not_affect_invalid_input(self, tmp_path):
        # Invalid input short-circuits before touching the artifact at all.
        service = GestureRecognitionService(artifact_path=tmp_path / "missing.joblib")
        result = service.recognize(None)
        assert result.gesture == GestureType.UNKNOWN


class TestNoForbiddenDependencies:
    """
    Static (AST-based) checks that app.dl does not import Robot, Vision,
    Decision, or ML -- independent of scripts/check_dl_dependencies.py,
    as a fast in-suite guardrail.
    """

    DL_DIR = Path(__file__).resolve().parent.parent.parent / "app" / "dl"
    FORBIDDEN_ROOTS = (
        "app.ml",
        "app.vision",
        "app.robot",
        "app.decision",
        "app.guide",
        "app.navigation",
        "app.ui",
        "app.main",
    )

    def _imports_in_file(self, path: Path) -> list[str]:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                modules.append(node.module)
        return modules

    def test_no_forbidden_imports_anywhere_in_app_dl(self):
        violations = []
        for py_file in sorted(self.DL_DIR.rglob("*.py")):
            for module in self._imports_in_file(py_file):
                for forbidden in self.FORBIDDEN_ROOTS:
                    if module == forbidden or module.startswith(forbidden + "."):
                        violations.append(f"{py_file.name}: imports {module!r}")
        assert violations == []
