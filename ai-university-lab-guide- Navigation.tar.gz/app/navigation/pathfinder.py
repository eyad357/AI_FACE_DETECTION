"""
Route calculation for Navigation.

Responsibility: given an adjacency-list graph (app.navigation.map_data)
and an origin/destination pair, compute the shortest route between
them. This module is pure graph algorithm -- it knows nothing about
NavigationResult, the public API, or the specific university map;
those belong to app.navigation.service and app.navigation.map_data
respectively.

Algorithm: Dijkstra's algorithm, chosen because the map has weighted
edges (simulated distances) -- see docs/navigation.md, "Routing
algorithm", for the BFS-vs-Dijkstra rationale. Ties are broken by
location id (lexicographic order) so results are fully deterministic
regardless of dict/heap iteration order.
"""

from __future__ import annotations

import heapq
from typing import Dict, List, Optional, Tuple


def find_shortest_path(
    adjacency: Dict[str, Dict[str, float]], origin: str, destination: str
) -> Optional[Tuple[List[str], float]]:
    """
    Compute the shortest path between two known locations.

    Args:
        adjacency: Graph as {location: {neighbor: distance}}, as
            produced by app.navigation.map_data.build_adjacency(). Both
            origin and destination must already be present as keys
            (callers are expected to validate this -- see
            app.navigation.service).
        origin: Starting location id.
        destination: Ending location id.

    Returns:
        A (route, total_distance) tuple where route is the ordered
        list of location ids from origin to destination (inclusive of
        both), and total_distance is the sum of edge distances along
        that route. If origin == destination, returns
        ([origin], 0.0). Returns None if no path exists (the
        destination is unreachable from the origin).
    """
    if origin == destination:
        return [origin], 0.0

    # Dijkstra's algorithm with a min-heap. Heap entries are
    # (distance, location) tuples; ties on distance are broken by
    # comparing location strings, which heapq does automatically via
    # tuple comparison, keeping route selection deterministic.
    distances: Dict[str, float] = {origin: 0.0}
    previous: Dict[str, str] = {}
    visited: set = set()
    heap: List[Tuple[float, str]] = [(0.0, origin)]

    while heap:
        current_distance, current = heapq.heappop(heap)

        if current in visited:
            continue
        visited.add(current)

        if current == destination:
            break

        for neighbor, edge_distance in sorted(adjacency.get(current, {}).items()):
            if neighbor in visited:
                continue
            candidate_distance = current_distance + edge_distance
            if candidate_distance < distances.get(neighbor, float("inf")):
                distances[neighbor] = candidate_distance
                previous[neighbor] = current
                heapq.heappush(heap, (candidate_distance, neighbor))

    if destination not in distances:
        return None

    # Reconstruct the route by walking `previous` back from destination.
    route: List[str] = [destination]
    node = destination
    while node != origin:
        node = previous[node]
        route.append(node)
    route.reverse()

    return route, distances[destination]
