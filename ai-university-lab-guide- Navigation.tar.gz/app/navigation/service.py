"""
Navigation public API — route planning service.

Responsibility: "How do I get from A to B?" Nothing more. This module
does NOT understand student language (that is app.ml's job), does not
decide when to navigate (that is a future Decision responsibility), and
does not move the robot (that is app.robot's job).

Usage:

    from app.navigation.service import NavigationService

    navigation = NavigationService()
    result = navigation.find_route("MAIN_GATE", "AI_LAB")  # -> NavigationResult

Callers do NOT need to know about the graph representation, the
routing algorithm, or how the map is stored -- all of that is
encapsulated in app.navigation.map_data and app.navigation.pathfinder.

Dependency rules (enforced, see docs/navigation.md and
app/navigation/__init__.py):
    Navigation MUST NOT import app.ml, app.dl, app.vision, app.robot,
    app.decision, app.guide, app.ui, or app.main.
    Navigation MAY use shared contracts from app.models.
"""

from __future__ import annotations

from app.models.schemas import NavigationResult
from app.navigation.map_data import build_adjacency, is_known_location
from app.navigation.pathfinder import find_shortest_path
from app.utils.logger import get_logger

logger = get_logger(__name__)

__all__ = ["NavigationService"]


class NavigationService:
    """
    Public entry point for university route planning.

    Loads the (static, in-memory) map once at construction time and
    answers find_route() calls against it. Stateless per-call beyond
    that -- safe to reuse a single instance across many requests.
    """

    def __init__(self) -> None:
        self._adjacency = build_adjacency()

    def find_route(self, origin: str, destination: str) -> NavigationResult:
        """
        Find the shortest route between two locations.

        Args:
            origin: Starting location id (see app.navigation.map_data
                for valid ids, e.g. "MAIN_GATE").
            destination: Ending location id.

        Returns:
            A NavigationResult. success=True with a populated route and
            distance if a path exists (including the trivial
            origin == destination case, which returns a single-element
            route with distance 0.0). success=False with a descriptive
            error if either location is unknown, or if the destination
            is unreachable from the origin.
        """
        origin_id = self._normalize(origin)
        destination_id = self._normalize(destination)

        if not is_known_location(origin_id):
            logger.warning("NavigationService.find_route: unknown origin %r", origin)
            return NavigationResult(
                success=False,
                origin=origin_id,
                destination=destination_id,
                error=f"Unknown origin location: {origin_id!r}",
            )

        if not is_known_location(destination_id):
            logger.warning(
                "NavigationService.find_route: unknown destination %r", destination
            )
            return NavigationResult(
                success=False,
                origin=origin_id,
                destination=destination_id,
                error=f"Unknown destination location: {destination_id!r}",
            )

        result = find_shortest_path(self._adjacency, origin_id, destination_id)

        if result is None:
            logger.info(
                "NavigationService.find_route: no route from %s to %s",
                origin_id,
                destination_id,
            )
            return NavigationResult(
                success=False,
                origin=origin_id,
                destination=destination_id,
                error=(
                    f"No route found between {origin_id!r} and "
                    f"{destination_id!r} (unreachable)"
                ),
            )

        route, distance = result
        return NavigationResult(
            success=True,
            origin=origin_id,
            destination=destination_id,
            route=route,
            distance=distance,
        )

    @staticmethod
    def _normalize(location: str) -> str:
        """
        Normalize caller-supplied location text for lookup.

        Trims surrounding whitespace and uppercases, so callers aren't
        required to know the map's exact id casing. Non-string input is
        stringified (never silently discarded) so the original value is
        still visible on a NavigationResult -- it will simply fail the
        "unknown location" check in find_route, same as any other
        unrecognized id.
        """
        if location is None:
            return ""
        if not isinstance(location, str):
            location = str(location)
        return location.strip().upper()
