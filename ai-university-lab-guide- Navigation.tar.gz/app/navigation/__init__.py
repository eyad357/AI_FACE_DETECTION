"""
Navigation — university map & route planning module.

Owner: Person 1 (AI / Intelligence).

Responsibility: represent the university map and compute routes
between two locations. Nothing more.

Flow:

    origin, destination (str)
          |
          v
    NavigationService.find_route()   (app.navigation.service)
          |
          v
    NavigationResult                  (app.models.schemas)

Internally:

    app.navigation.service
          |
          v
    app.navigation.pathfinder   (Dijkstra, over a graph built from...)
          |
          v
    app.navigation.map_data     (static in-memory university map)

Navigation is NOT responsible for:
    - understanding student language (app.ml)
    - classifying intents (app.ml)
    - gesture recognition (app.dl)
    - face detection (app.vision)
    - deciding when to navigate (future app.decision)
    - robot movement / speech (app.robot)
    - UI

Dependency rules (enforced -- see docs/navigation.md):
    Navigation MUST NOT import app.ml, app.dl, app.vision, app.robot,
    app.decision, app.guide, app.ui, or app.main.
    Navigation communicates via shared contracts in app.models only.

This package contains:
    map_data.py    static university map (locations + weighted edges)
    pathfinder.py   Dijkstra shortest-path algorithm (pure graph logic)
    service.py      public API (NavigationService)

Navigation does NOT perform integration: it is not wired into
app.decision, app.robot, or app.main in this phase. That remains a
future integration phase -- see docs/navigation.md, "Future
integration point".
"""
