"""
University map data for Navigation.

Responsibility: represent the university locations and the weighted
connections (edges) between them, as a small, static, in-memory graph.
This module holds ONLY data plus small read-only accessors -- routing
logic itself lives in app.navigation.pathfinder.

Distances below are simulated demonstration values (approximate
walking distance in meters between adjacent locations on a small
campus), NOT measurements of any real institution. They exist to make
route-cost calculation demonstrable and are documented here as such
(see docs/navigation.md, "Map representation").

To extend the map: add a location to LOCATIONS (if it introduces a new
id) and an edge to _EDGES, then re-run tests/navigation/ to confirm
nothing broke. See docs/navigation.md, "How to extend the map".
"""

from __future__ import annotations

from typing import Dict, List, Tuple

# Location ids. Kept as plain strings (not an Enum) so the map stays
# easy to extend without touching a shared contract -- the shared
# NavigationResult (app.models.schemas) already stores locations as
# plain strings for the same reason.
MAIN_GATE = "MAIN_GATE"
ADMINISTRATION = "ADMINISTRATION"
LIBRARY = "LIBRARY"
COMPUTER_BUILDING = "COMPUTER_BUILDING"
AI_LAB = "AI_LAB"
ROBOTICS_LAB = "ROBOTICS_LAB"
LECTURE_HALL_A = "LECTURE_HALL_A"
LECTURE_HALL_B = "LECTURE_HALL_B"
STUDENT_AFFAIRS = "STUDENT_AFFAIRS"
CAFETERIA = "CAFETERIA"

# OLD_ANNEX is an intentionally disconnected demo location (no edges),
# included specifically so unreachable-destination behavior is
# demonstrable and testable (see docs/navigation.md).
OLD_ANNEX = "OLD_ANNEX"

LOCATIONS: Tuple[str, ...] = (
    MAIN_GATE,
    ADMINISTRATION,
    LIBRARY,
    COMPUTER_BUILDING,
    AI_LAB,
    ROBOTICS_LAB,
    LECTURE_HALL_A,
    LECTURE_HALL_B,
    STUDENT_AFFAIRS,
    CAFETERIA,
    OLD_ANNEX,
)

# Undirected weighted edges: (location_a, location_b, distance_meters).
# Distances are simulated demo values -- see module docstring.
_EDGES: List[Tuple[str, str, float]] = [
    (MAIN_GATE, ADMINISTRATION, 100.0),
    (MAIN_GATE, LIBRARY, 150.0),
    (ADMINISTRATION, LIBRARY, 60.0),
    (ADMINISTRATION, COMPUTER_BUILDING, 120.0),
    (LIBRARY, COMPUTER_BUILDING, 90.0),
    (LIBRARY, CAFETERIA, 70.0),
    (COMPUTER_BUILDING, AI_LAB, 50.0),
    (COMPUTER_BUILDING, LECTURE_HALL_A, 80.0),
    (AI_LAB, ROBOTICS_LAB, 40.0),
    (LECTURE_HALL_A, LECTURE_HALL_B, 30.0),
    (CAFETERIA, STUDENT_AFFAIRS, 60.0),
    (LECTURE_HALL_B, STUDENT_AFFAIRS, 100.0),
    # OLD_ANNEX intentionally has no edges -- see its definition above.
]


def build_adjacency() -> Dict[str, Dict[str, float]]:
    """
    Build an adjacency-list representation of the map.

    Returns:
        A dict mapping each location id to a dict of
        {neighbor_location_id: distance}. Every id in LOCATIONS is
        present as a key, even if it has no neighbors (e.g. OLD_ANNEX
        maps to an empty dict).
    """
    adjacency: Dict[str, Dict[str, float]] = {location: {} for location in LOCATIONS}
    for a, b, distance in _EDGES:
        adjacency[a][b] = distance
        adjacency[b][a] = distance
    return adjacency


def is_known_location(location: str) -> bool:
    """Return True if location is a valid location id on this map."""
    return location in LOCATIONS
