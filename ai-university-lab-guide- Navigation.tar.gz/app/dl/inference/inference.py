"""
Runtime inference for the DL gesture recognizer.

Responsibility: load a previously trained artifact (produced offline by
app.dl.training.train) and use it to classify a single landmark feature
vector at request time. This module never trains or retrains a model.

Consumed by app.dl.service, which exposes the public API. Callers
outside app.dl should not import this module directly.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence, Tuple

# Single source of truth for the default trained-artifact location.
# app.dl.training.train writes here; this module reads from here.
ARTIFACT_DIR = Path(__file__).resolve().parent.parent / "artifacts"
DEFAULT_ARTIFACT_PATH = ARTIFACT_DIR / "gesture_classifier.joblib"

_PIPELINE_CACHE: dict = {}


class ArtifactNotFoundError(RuntimeError):
    """
    Raised when a trained model artifact cannot be found on disk.

    Runtime inference deliberately does NOT fall back to silently
    training a model -- if this is raised, run the offline training
    pipeline first (see docs/dl.md: "Training process").
    """


def load_pipeline(artifact_path: Path = DEFAULT_ARTIFACT_PATH):
    """
    Load a trained feature-scaling + MLP pipeline from disk.

    Results are cached in-process per artifact_path so repeated calls
    (e.g. many predictions in the same run) don't re-read the file.

    Args:
        artifact_path: Path to a joblib-serialized sklearn Pipeline
            produced by app.dl.training.train.

    Returns:
        The deserialized sklearn Pipeline.

    Raises:
        ArtifactNotFoundError: if no artifact exists at artifact_path.
    """
    cache_key = str(artifact_path)
    if cache_key in _PIPELINE_CACHE:
        return _PIPELINE_CACHE[cache_key]

    if not artifact_path.exists():
        raise ArtifactNotFoundError(
            f"No trained DL artifact found at {artifact_path}. "
            "Run the offline training pipeline first: "
            "`python -m app.dl.training.train` "
            "(see docs/dl.md)."
        )

    import joblib

    pipeline = joblib.load(artifact_path)
    _PIPELINE_CACHE[cache_key] = pipeline
    return pipeline


def predict_gesture(
    landmarks: Sequence[float], artifact_path: Path = DEFAULT_ARTIFACT_PATH
) -> Tuple[str, float]:
    """
    Classify a single landmark feature vector using the trained
    pipeline.

    Args:
        landmarks: A validated 42-float landmark vector (see
            app.dl.models.landmark_schema; validation is the caller's
            responsibility -- see app.dl.service).
        artifact_path: Path to the trained artifact to use.

    Returns:
        A (predicted_gesture_label, confidence) tuple, where
        predicted_gesture_label is a GestureType member name (str) and
        confidence is the model's predicted probability for that class,
        in [0.0, 1.0].

    Raises:
        ArtifactNotFoundError: if no trained artifact exists.
    """
    pipeline = load_pipeline(artifact_path)

    probabilities = pipeline.predict_proba([list(landmarks)])[0]
    classes = pipeline.classes_

    best_index = probabilities.argmax()
    predicted_label = str(classes[best_index])
    confidence = float(probabilities[best_index])

    return predicted_label, confidence


def clear_cache() -> None:
    """Clear the in-process pipeline cache. Primarily useful for tests."""
    _PIPELINE_CACHE.clear()
