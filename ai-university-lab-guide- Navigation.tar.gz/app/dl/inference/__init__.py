"""
Inference — runtime gesture prediction for the DL gesture recognizer.

Responsibility: load a trained artifact from app.dl.artifacts and run
inference (landmark vector -> gesture) at request time. Consumed by
app.dl.service, which exposes the public GestureRecognitionService API.

See app.dl.inference.inference for the implementation.
"""
