"""
Dataset — synthetic hand-landmark training data for the DL gesture
recognizer.

Design decision (see docs/dl.md, "Training process", for full
rationale): this environment has no camera hardware and no network
access to a real, licensed hand-gesture image/landmark dataset. Rather
than fabricate an implausible "real" dataset, this module generates a
small, deterministic, seeded set of landmark feature vectors from
explicit, documented geometric templates -- one per gesture class,
built from simple per-finger "curl" and hand-position parameters -- plus
bounded random noise. This keeps the dataset:

    - reproducible (fixed seed, same output every run)
    - explainable (every class's template is a readable parameter set,
      not a black box)
    - small (matches app.ml's precedent of a small, non-repetitive
      dataset rather than hundreds of near-duplicate rows)

Format: each example is a (landmarks, gesture_name) pair, where
landmarks is a 42-float vector (see app.dl.models.landmark_schema) and
gesture_name is a GestureType member name (WAVE, STOP, or POINT --
UNKNOWN is a runtime-only fallback, never a training label, matching
app.ml's precedent for its own UNKNOWN handling).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from app.dl.models.landmark_schema import NUM_FEATURES
from app.models.schemas import GestureType

# Labeled training classes. UNKNOWN is never a training label -- it is
# only a runtime fallback for low-confidence predictions (app.dl.service).
_LABELED_GESTURES = tuple(
    name for name in GestureType.__members__ if name != GestureType.UNKNOWN.name
)

_FINGERS = ("thumb", "index", "middle", "ring", "pinky")
_FINGER_X = {"thumb": 0.30, "index": 0.42, "middle": 0.50, "ring": 0.58, "pinky": 0.66}
_JOINTS_PER_FINGER = 4
_PALM_Y = 0.85
_THUMB_TIP_Y = 0.45  # thumb never extends as high as the other fingers
_OTHER_TIP_Y = 0.15


@dataclass(frozen=True)
class GestureTemplate:
    """
    A hand-pose template for one gesture class.

    Attributes:
        finger_curl: Per-finger curl amount, 0.0 = fully extended
            (fingertip near the top of the frame), 1.0 = fully curled
            (fingertip near the palm).
        x_offset: Horizontal shift of the whole hand, added to every
            landmark's x coordinate (used to distinguish WAVE's
            off-center hand position from STOP's centered one).
        y_offset: Vertical shift of the whole hand, added to every
            landmark's y coordinate.
    """

    finger_curl: Dict[str, float]
    x_offset: float = 0.0
    y_offset: float = 0.0


# One documented template per labeled gesture class:
#   STOP:  open palm, all five fingers extended, centered -- the
#          universal "halt" hand shape.
#   POINT: only the index finger extended, the rest curled into the
#          palm -- an unambiguous pointing shape.
#   WAVE:  an open palm like STOP, but raised and shifted to one side,
#          approximating the raised, off-center hand position typical
#          of a wave (this phase classifies a single static frame, not
#          motion across frames -- see docs/dl.md, "Limitations").
_TEMPLATES: Dict[str, GestureTemplate] = {
    "STOP": GestureTemplate(
        finger_curl={f: 0.0 for f in _FINGERS},
    ),
    "POINT": GestureTemplate(
        finger_curl={"thumb": 1.0, "index": 0.0, "middle": 1.0, "ring": 1.0, "pinky": 1.0},
    ),
    "WAVE": GestureTemplate(
        finger_curl={f: 0.0 for f in _FINGERS},
        x_offset=0.14,
        y_offset=-0.08,
    ),
}


def _template_to_landmarks(template: GestureTemplate) -> List[float]:
    """Expand a GestureTemplate into a flat 42-float landmark vector."""
    wrist_x = 0.5 + template.x_offset
    wrist_y = _PALM_Y + template.y_offset
    flat: List[float] = [wrist_x, wrist_y]

    for finger in _FINGERS:
        curl = template.finger_curl[finger]
        base_x = _FINGER_X[finger] + template.x_offset
        base_y = _PALM_Y + template.y_offset
        tip_y_extended = (_THUMB_TIP_Y if finger == "thumb" else _OTHER_TIP_Y) + (
            template.y_offset
        )
        tip_y = base_y - (base_y - tip_y_extended) * (1.0 - curl)

        for joint in range(1, _JOINTS_PER_FINGER + 1):
            fraction = joint / _JOINTS_PER_FINGER
            y = base_y + (tip_y - base_y) * fraction
            flat.extend([base_x, y])

    assert len(flat) == NUM_FEATURES  # 1 wrist + 5 fingers * 4 joints, all (x, y)
    return [min(1.0, max(0.0, v)) for v in flat]


def generate_dataset(
    samples_per_class: int = 40, seed: int = 42, noise_std: float = 0.02
) -> List[Tuple[List[float], str]]:
    """
    Generate the synthetic, deterministic landmark training dataset.

    Args:
        samples_per_class: How many noisy samples to generate per
            gesture class.
        seed: Random seed for the noise generator -- fixed by default
            so training is fully reproducible.
        noise_std: Standard deviation of the Gaussian noise added to
            each template landmark, before clipping to [0.0, 1.0].

    Returns:
        A list of (landmarks, gesture_name) pairs, gesture_name being a
        GestureType member name.
    """
    rng = np.random.default_rng(seed)
    examples: List[Tuple[List[float], str]] = []

    for gesture_name in _LABELED_GESTURES:
        template = _TEMPLATES[gesture_name]
        base = np.array(_template_to_landmarks(template), dtype=float)
        for _ in range(samples_per_class):
            noisy = base + rng.normal(0.0, noise_std, size=base.shape)
            noisy = np.clip(noisy, 0.0, 1.0)
            examples.append((noisy.tolist(), gesture_name))

    return examples
