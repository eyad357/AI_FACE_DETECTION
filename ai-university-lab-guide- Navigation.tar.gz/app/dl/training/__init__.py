"""
Training — offline training pipeline for the DL gesture recognizer.

Responsibility: fit a small MLP (multi-layer perceptron) neural network
on the synthetic landmark dataset (app.dl.dataset) and persist it to
app.dl.artifacts.

See app.dl.training.train for the actual pipeline. This package
intentionally does not import that module at package-import time, so
importing app.dl.training (and anything that transitively imports
app.dl) never pulls in scikit-learn's training-time dependencies unless
training is explicitly requested.

Training is offline-only: run explicitly via

    python -m app.dl.training.train

It must never run automatically as a side effect of application
startup or runtime inference (see app.dl.inference / app.dl.service).
"""
