"""
Offline training pipeline for the DL gesture recognizer.

Responsibility: turn the synthetic landmark dataset (app.dl.dataset)
into a trained, small feed-forward neural network (multi-layer
perceptron), evaluate it on a held-out split, and persist it to
app.dl.artifacts so app.dl.inference can load it at runtime WITHOUT
retraining.

Model choice: a small scikit-learn MLPClassifier (a genuine multi-layer
neural network, trained by backpropagation -- i.e. deep learning, as
distinct from app.ml's linear Logistic Regression). scikit-learn is
already a project dependency (added for app.ml), so this avoids pulling
in a much heavier framework (PyTorch/TensorFlow) for a 42-input,
3-class classifier where that would add size and complexity without a
reliability benefit -- see docs/dl.md, "Model choice", for the full
comparison.

This module is run explicitly, offline, e.g.:

    python -m app.dl.training.train

It must never be imported or executed automatically by application
runtime code (see app.dl.inference / app.dl.service).
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from app.dl.dataset import generate_dataset

ARTIFACT_DIR = Path(__file__).resolve().parent.parent / "artifacts"
DEFAULT_ARTIFACT_PATH = ARTIFACT_DIR / "gesture_classifier.joblib"

# Kept small and fixed for reproducible offline training on a tiny,
# synthetic dataset; not a runtime-tunable setting (see
# app.config.DLConfig for genuinely runtime-relevant DL settings).
_RANDOM_STATE = 42
_TEST_SIZE = 0.25


@dataclass(frozen=True)
class DLTrainingResult:
    """Summary of a single training run, returned for reporting/tests."""

    accuracy: float
    report: str
    train_size: int
    test_size: int
    artifact_path: Path


def _build_pipeline() -> Pipeline:
    """Construct an untrained feature-scaling + MLP pipeline."""
    return Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            (
                "clf",
                MLPClassifier(
                    hidden_layer_sizes=(16,),
                    activation="relu",
                    max_iter=2000,
                    random_state=_RANDOM_STATE,
                ),
            ),
        ]
    )


def train(
    samples_per_class: int = 40,
    seed: int = 42,
    artifact_path: Path = DEFAULT_ARTIFACT_PATH,
) -> DLTrainingResult:
    """
    Train the gesture classifier and persist it to disk.

    Args:
        samples_per_class: How many synthetic samples per gesture class
            to generate for training/evaluation (see app.dl.dataset).
        seed: Random seed for synthetic dataset generation.
        artifact_path: Where to save the fitted pipeline (joblib).

    Returns:
        A DLTrainingResult summarizing accuracy and split sizes.

    Raises:
        ValueError: if the generated dataset is too small to
            stratify/split.
    """
    examples: List[Tuple[List[float], str]] = generate_dataset(
        samples_per_class=samples_per_class, seed=seed
    )

    features = [e[0] for e in examples]
    labels = [e[1] for e in examples]

    class_counts: dict = {}
    for label in labels:
        class_counts[label] = class_counts.get(label, 0) + 1
    if min(class_counts.values()) < 2:
        raise ValueError(
            "Each gesture class needs at least 2 examples to allow a "
            f"train/test split; got counts={class_counts}"
        )

    x_train, x_test, y_train, y_test = train_test_split(
        features,
        labels,
        test_size=_TEST_SIZE,
        random_state=_RANDOM_STATE,
        stratify=labels,
    )

    pipeline = _build_pipeline()
    pipeline.fit(x_train, y_train)

    y_pred = pipeline.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, zero_division=0)

    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    import joblib

    joblib.dump(pipeline, artifact_path)

    return DLTrainingResult(
        accuracy=float(accuracy),
        report=report,
        train_size=len(x_train),
        test_size=len(x_test),
        artifact_path=artifact_path,
    )


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Train the MLP-based DL gesture classifier."
    )
    parser.add_argument(
        "--samples-per-class",
        type=int,
        default=40,
        help="Synthetic samples to generate per gesture class.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=DEFAULT_ARTIFACT_PATH,
        help="Where to save the trained artifact.",
    )
    args = parser.parse_args()

    result = train(samples_per_class=args.samples_per_class, artifact_path=args.out)

    print(f"Train examples: {result.train_size}")
    print(f"Test examples:  {result.test_size}")
    print(f"Accuracy:       {result.accuracy:.3f}")
    print()
    print(result.report)
    print(f"Artifact saved to: {result.artifact_path}")
    return 0


if __name__ == "__main__":
    sys.exit(_main())
