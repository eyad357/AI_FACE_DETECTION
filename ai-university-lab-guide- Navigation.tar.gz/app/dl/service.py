"""
DL public API — gesture recognition service.

Responsibility: "What gesture is being performed?" Nothing more. This
module does NOT decide what the robot should do about the gesture
(greet, stop, navigate, speak) -- that remains a future orchestration
layer's job (app.main), mirroring how app.ml.service only classifies
intent and does not act on it.

Usage:

    from app.dl.service import GestureRecognitionService

    service = GestureRecognitionService()
    result = service.recognize(landmarks)  # -> GestureResult

`landmarks` is a 42-float hand-landmark feature vector (21 (x, y)
points, normalized to [0.0, 1.0] -- see
app.dl.models.landmark_schema). Callers do NOT need to know about the
neural network architecture, feature scaling, the artifact file format,
or preprocessing -- all of that is encapsulated in app.dl.inference.

Dependency rules (enforced, see docs/dl.md and app/dl/__init__.py):
    DL MUST NOT import app.ml, app.vision, app.robot, app.decision,
    app.guide, app.navigation, app.ui, or app.main.
    DL MAY use shared contracts from app.models.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Sequence

from app.config import CONFIG
from app.dl.inference.inference import (
    ArtifactNotFoundError,
    DEFAULT_ARTIFACT_PATH,
    predict_gesture,
)
from app.dl.models.landmark_schema import LandmarkValidationError, validate_landmarks
from app.models.schemas import GestureResult, GestureType
from app.utils.logger import get_logger

logger = get_logger(__name__)

__all__ = ["GestureRecognitionService", "ArtifactNotFoundError", "LandmarkValidationError"]


class GestureRecognitionService:
    """
    Public entry point for DL gesture recognition.

    A thin, stateless-from-the-caller's-perspective wrapper around
    app.dl.inference: it loads the trained artifact (once, lazily) and
    turns a landmark feature vector into a validated GestureResult.
    """

    def __init__(self, artifact_path: Optional[Path] = None) -> None:
        """
        Args:
            artifact_path: Optional override for the trained artifact
                location. Defaults to app.config.CONFIG.dl.artifact_dir
                (if set) or the bundled app/dl/artifacts location.
        """
        if artifact_path is not None:
            self._artifact_path = artifact_path
        elif CONFIG.dl.artifact_dir:
            self._artifact_path = (
                Path(CONFIG.dl.artifact_dir) / DEFAULT_ARTIFACT_PATH.name
            )
        else:
            self._artifact_path = DEFAULT_ARTIFACT_PATH

    def recognize(self, landmarks: Sequence[float]) -> GestureResult:
        """
        Classify a hand-landmark feature vector into a gesture.

        Args:
            landmarks: A 42-float sequence (21 (x, y) points, each
                normalized to [0.0, 1.0] -- see
                app.dl.models.landmark_schema.validate_landmarks).

        Returns:
            A GestureResult with the predicted gesture, confidence, and
            a UTC timestamp. If landmarks fails schema validation, or
            the model's confidence falls below
            CONFIG.dl.min_confidence, the result's gesture is
            GestureType.UNKNOWN (confidence 0.0 for invalid input; the
            model's own confidence otherwise).

        Raises:
            ArtifactNotFoundError: if no trained model artifact exists.
                Runtime inference never trains automatically -- see
                docs/dl.md ("Training process").
        """
        try:
            validate_landmarks(landmarks)
        except LandmarkValidationError as exc:
            logger.warning("GestureRecognitionService.recognize: invalid input: %s", exc)
            return GestureResult(
                gesture=GestureType.UNKNOWN,
                confidence=0.0,
                timestamp=datetime.now(timezone.utc),
            )

        label, confidence = predict_gesture(
            landmarks, artifact_path=self._artifact_path
        )

        if confidence < CONFIG.dl.min_confidence:
            logger.info(
                "Prediction confidence %.3f below threshold %.3f; "
                "returning UNKNOWN",
                confidence,
                CONFIG.dl.min_confidence,
            )
            gesture = GestureType.UNKNOWN
        else:
            gesture = GestureType[label]

        return GestureResult(
            gesture=gesture,
            confidence=confidence,
            timestamp=datetime.now(timezone.utc),
        )
