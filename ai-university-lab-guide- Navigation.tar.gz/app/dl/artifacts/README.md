# DL artifacts

Trained model artifact(s) for `app.dl` (gesture recognition), produced
offline by `python -m app.dl.training.train`.

- `gesture_classifier.joblib` — a scikit-learn `Pipeline`
  (`StandardScaler` + `MLPClassifier`) trained on the synthetic
  landmark dataset (`app.dl.dataset`). Loaded at runtime by
  `app.dl.inference.inference.load_pipeline`.

Do not edit these files by hand. To regenerate, see `docs/dl.md` ("How
to train").
