"""
Landmark input schema for the DL gesture recognizer.

Design decision (see docs/dl.md, "Model choice", for full rationale):

This phase's DL model classifies gestures from a fixed-length numeric
hand-landmark feature vector, not raw camera pixels. The vector layout
follows the widely-used 21-point hand landmark schema (as produced by
common hand-landmark detectors): 21 (x, y) pairs, each normalized to
[0.0, 1.0] relative to the frame, flattened to 42 floats.

This keeps the DL classifier itself small, explainable, and fully
testable without a camera or a pretrained landmark-extraction network,
while using an input contract that a future landmark-extraction stage
(added in a later phase) can populate directly -- no interface change
needed downstream.
"""

from __future__ import annotations

from typing import Sequence

NUM_LANDMARKS = 21
NUM_FEATURES = NUM_LANDMARKS * 2  # (x, y) per landmark


class LandmarkValidationError(ValueError):
    """Raised when a landmark feature vector does not match the schema."""


def validate_landmarks(landmarks: Sequence[float]) -> None:
    """
    Validate a landmark feature vector against the DL input schema.

    Args:
        landmarks: A sequence expected to contain NUM_FEATURES floats,
            each normalized to [0.0, 1.0].

    Raises:
        LandmarkValidationError: If landmarks is None, not a sequence,
            the wrong length, contains non-numeric values, or contains
            values outside [0.0, 1.0].
    """
    if landmarks is None:
        raise LandmarkValidationError("landmarks must not be None")
    if isinstance(landmarks, (str, bytes)):
        raise LandmarkValidationError(
            f"landmarks must be a numeric sequence, got {type(landmarks).__name__}"
        )
    try:
        values = list(landmarks)
    except TypeError:
        raise LandmarkValidationError(
            f"landmarks must be an iterable sequence, got {type(landmarks).__name__}"
        ) from None

    if len(values) != NUM_FEATURES:
        raise LandmarkValidationError(
            f"landmarks must contain exactly {NUM_FEATURES} values "
            f"({NUM_LANDMARKS} landmarks x 2 coordinates), got {len(values)}"
        )

    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise LandmarkValidationError(
                f"landmarks must contain only numeric values, got {value!r}"
            )
        if not (0.0 <= float(value) <= 1.0):
            raise LandmarkValidationError(
                f"landmark coordinates must be within [0.0, 1.0], got {value}"
            )
