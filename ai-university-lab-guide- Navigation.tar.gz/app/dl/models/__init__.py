"""
Models — the DL gesture recognizer's input schema.

Responsibility: define and validate the fixed-length hand-landmark
feature vector that app.dl's neural network operates on (see
landmark_schema.py). This is DL's own internal input contract, distinct
from the shared cross-module result contracts (GestureResult,
GestureType) which live in app.models.schemas.
"""
