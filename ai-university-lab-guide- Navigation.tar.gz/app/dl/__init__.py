"""
DL — Deep Learning module (gesture recognition).

Owner: Person 1 (AI / Intelligence).

Responsibility: recognize a physical hand gesture from a landmark
feature vector, so a future orchestration layer (app.main) can decide
whether to greet, stop, navigate, or otherwise react. This is a deep
learning task (a small trained neural network), distinct from
app.ml's classic-ML text intent classification, and distinct from
app.vision's face detection.

Flow:

    Landmark feature vector (42 floats)
          |
          v
    GestureRecognitionService.recognize()  (app.dl.service)
          |
          v
    GestureResult  (app.models.schemas)

Gestures: WAVE, STOP, POINT, UNKNOWN.
Approach: a small MLP (multi-layer perceptron) neural network trained
offline on a synthetic, seeded landmark dataset -- see docs/dl.md for
the full rationale (no camera hardware or network access to a real
gesture dataset is available in this environment).

IMPORTANT — this module does NOT modify or replace app.vision. Face
detection remains app.vision's responsibility; gesture recognition is a
separate, additive capability.

Dependency rules (enforced -- see docs/dl.md):
    DL MUST NOT import app.ml, app.vision, app.robot, app.decision,
    app.guide, app.navigation, app.ui, or app.main.
    DL communicates via shared contracts in app.models only.

This package contains:
    models/     landmark input schema + validation (DL's own contract)
    dataset/    synthetic landmark dataset generator
    training/   offline training pipeline (never runs at runtime)
    inference/  runtime prediction from a trained artifact
    artifacts/  trained model artifact(s)
    service.py  public API (GestureRecognitionService)

DL does NOT perform integration: it does not call Decision, Robot,
Navigation, Guide, or UI, and it is not wired into app.main in this
phase. That remains a future integration phase.
"""
