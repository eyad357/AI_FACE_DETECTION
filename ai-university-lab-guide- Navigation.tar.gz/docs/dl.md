# DL — Gesture Recognition

Owner: Person 1 (AI / Intelligence).

## 1. Purpose

Given a hand pose, determine which gesture is being performed — so a
future orchestration layer can decide how to react.

## 2. Architecture

```
Landmark feature vector (42 floats)
      |
      v
GestureRecognitionService.recognize()   (app.dl.service)
      |
      v
GestureResult                            (app.models.schemas)
```

Internally, `GestureRecognitionService` delegates to:

```
app.dl.service
      |
      v
app.dl.inference.inference   (loads trained artifact, runs prediction)
      |
      v
app.dl.artifacts/gesture_classifier.joblib   (trained offline)
```

Offline, separately:

```
app.dl.dataset (synthetic landmark generator)
      |
      v
app.dl.training.train   (StandardScaler + MLPClassifier, evaluation)
      |
      v
app.dl.artifacts/gesture_classifier.joblib
```

Training and inference are split exactly as in `app.ml`: **training
never runs at request time**, and **inference never retrains**.

DL only recognizes the gesture — it does not decide what the robot
should do (greet, stop, navigate). That belongs to a future
orchestration/decision phase, exactly as `app.ml` only classifies
intent without acting on it.

### Package layout

```
app/dl/
├── __init__.py         module overview
├── models/
│   ├── __init__.py
│   └── landmark_schema.py   input schema + validation (DL's own contract)
├── dataset/
│   └── __init__.py          synthetic landmark dataset generator
├── training/
│   ├── __init__.py
│   └── train.py              offline training pipeline (run manually)
├── inference/
│   ├── __init__.py
│   └── inference.py          runtime prediction from a trained artifact
├── artifacts/
│   ├── README.md
│   └── gesture_classifier.joblib   trained pipeline (committed)
└── service.py                 public API: GestureRecognitionService
```

## 3. Model choice

**Model:** a small `scikit-learn` pipeline — `StandardScaler` +
`MLPClassifier` (a multi-layer perceptron: an input layer, one 16-unit
ReLU hidden layer, and a softmax output layer, trained by
backpropagation). This is genuine deep learning (a trained neural
network), distinct from `app.ml`'s linear Logistic Regression.

**Why this over alternatives:**

- **Pretrained CNN / a hand-gesture model hub download** — this
  environment has no network access to model hubs (only PyPI/GitHub
  package registries are reachable), so a pretrained image or landmark
  model cannot reliably be fetched or verified. Depending on an
  unreachable download would violate the phase's own "reliability"
  priority.
- **PyTorch/TensorFlow** — would add a large, heavy new dependency for
  a 42-input, 3-class classification problem where a small MLP is
  already more than sufficient; violates "do not choose a complicated
  model simply because it is technically impressive."
- **`scikit-learn` `MLPClassifier`** — `scikit-learn` is already a
  project dependency (added for `app.ml`), so this adds zero new
  third-party packages, is fast to train and load, fully deterministic
  given a fixed seed, and small enough to be genuinely explainable
  (one hidden layer, 16 units).

This satisfies the phase's stated priorities in order: reliability,
simplicity, reproducibility, explainability, independent testing,
future integration.

## 4. Input: landmark feature vector (not raw pixels)

**Design decision:** the classifier operates on a **42-float hand
landmark vector** (21 `(x, y)` points, each normalized to `[0.0, 1.0]`
relative to the frame — the same layout widely used by hand-landmark
detectors), not on raw camera pixels.

**Why:** classifying gestures directly from raw pixels would require
either (a) a pretrained CNN, which is not reliably obtainable in this
network-restricted environment (see "Model choice" above), or (b)
training a CNN from scratch on real gesture images, for which no
camera hardware or licensed image dataset is available here. A
landmark-vector input keeps the classifier itself small and testable
without a camera, while matching the standard interface a future
landmark-extraction stage (e.g. a dedicated detector added in a later
phase) would naturally produce — so this module is a drop-in consumer
once that stage exists, with no interface change required.

See `app.dl.models.landmark_schema` for the exact schema and
validation rules.

## 5. Gesture classes

| Gesture | Hand shape | 
|---|---|
| `STOP` | Open palm, all five fingers extended, centered. |
| `POINT` | Only the index finger extended; other fingers curled into the palm. |
| `WAVE` | Open palm like `STOP`, but raised and shifted to one side (see "Limitations" below). |
| `UNKNOWN` | Runtime-only fallback; never a training label (see below). |

`UNKNOWN` is returned when the input fails schema validation, or when
the model's confidence falls below `CONFIG.dl.min_confidence` (`0.0`
by default — effectively disabled unless explicitly configured).

## 6. `GestureResult` contract

Defined in `app/models/schemas.py` (the project's single canonical
contracts module, alongside `IntentType`/`IntentResult` from `app.ml`):

```python
class GestureType(Enum):
    WAVE = "WAVE"
    STOP = "STOP"
    POINT = "POINT"
    UNKNOWN = "UNKNOWN"

@dataclass(frozen=True)
class GestureResult:
    gesture: GestureType
    confidence: float   # validated to be within [0.0, 1.0]
    timestamp: datetime  # UTC, set internally at recognition time
```

## 7. Inference process

1. `GestureRecognitionService.recognize(landmarks)` is called.
2. `landmarks` is validated against the schema
   (`app.dl.models.landmark_schema.validate_landmarks`). Invalid input
   (wrong length, out-of-range values, non-numeric, `None`, etc.)
   short-circuits to `GestureResult(UNKNOWN, confidence=0.0, ...)`
   without touching the model at all.
3. Otherwise, `app.dl.inference.inference.predict_gesture` loads the
   trained pipeline (cached in-process after the first load) and calls
   `pipeline.predict_proba([landmarks])`.
4. The highest-probability class and its probability become the
   predicted gesture and confidence.
5. If confidence is below `CONFIG.dl.min_confidence`, the gesture is
   downgraded to `UNKNOWN` (confidence still reports the model's actual
   value).
6. The result is wrapped in a validated `GestureResult` with a UTC
   timestamp.

If no trained artifact exists on disk, `predict_gesture` raises
`ArtifactNotFoundError` immediately — it does **not** silently trigger
training.

## 8. Training process

Offline only:

1. Generate the synthetic landmark dataset (`app.dl.dataset`): for
   each of `WAVE`/`STOP`/`POINT`, expand a documented geometric
   template (per-finger "curl" amount + hand x/y offset) into a base
   42-float landmark vector, then add bounded Gaussian noise
   (fixed seed) to produce multiple samples per class.
2. Stratified train/test split (75/25, fixed random seed).
3. Fit `StandardScaler` + `MLPClassifier` (one 16-unit hidden layer) on
   the training set.
4. Evaluate on the held-out test split (accuracy + per-class
   precision/recall/F1).
5. Persist the fitted `sklearn.pipeline.Pipeline` to
   `app/dl/artifacts/gesture_classifier.joblib` via `joblib`.

**Why a synthetic dataset instead of real gesture data:** this
environment has no camera hardware and no network access to a real,
licensed hand-gesture dataset. A small, deterministic, seeded
generator built from explicit geometric templates keeps the dataset
reproducible and fully explainable (every class's template is a
readable parameter set, not an opaque download), consistent with
`app.ml`'s precedent of a small, non-repetitive, human-understandable
dataset — this is the documented assumption for this phase.

Training **never** happens automatically as a side effect of importing
`app.dl` or running the application.

## 9. Artifact handling

- The trained artifact (`app/dl/artifacts/gesture_classifier.joblib`)
  is committed to the repository, so runtime inference works
  out-of-the-box without training.
- `GestureRecognitionService` resolves the artifact path from
  `CONFIG.dl.artifact_dir` (if set) or the bundled default location.
- If the artifact is missing, `ArtifactNotFoundError` is raised with a
  clear message pointing to the training command below — never a
  silent retrain.

## 10. How to train

```bash
cd ai-university-lab-guide
pip install -r requirements.txt
python -m app.dl.training.train
```

Optional flags:

```bash
python -m app.dl.training.train --samples-per-class 60 --out path/to/artifact.joblib
```

## 11. How to run inference

```python
from app.dl.service import GestureRecognitionService
from app.dl.dataset import _TEMPLATES, _template_to_landmarks

service = GestureRecognitionService()
landmarks = _template_to_landmarks(_TEMPLATES["STOP"])  # or a real landmark vector
result = service.recognize(landmarks)
print(result.gesture, result.confidence)
```

## 12. Testing

```bash
# DL tests only
pytest tests/dl/ -v

# Full suite (existing + ML + DL)
pytest -v
```

Tests are fully hardware-independent: they operate on landmark feature
vectors (numeric lists), never on camera frames, so no physical camera
or camera SDK is required. `tests/dl/test_service.py` also includes a
static AST-based guardrail confirming `app.dl` never imports
`app.robot`, `app.vision`, `app.decision`, `app.guide`,
`app.navigation`, `app.ui`, `app.main`, or the locked `app.ml`.

## 13. Performance

Measured on the committed artifact, on the container CPU used for this
phase's implementation (see `tests/dl/` for the code paths exercised):

| Metric | Measured value |
|---|---|
| Model load time (`load_pipeline`, cold, first call in a process) | ~750 ms (dominated by one-time `scikit-learn`/`joblib` import cost, not the artifact itself) |
| Model load time (cached, subsequent calls) | ~0.007 ms (in-process cache) |
| Single-input inference time (`predict_gesture`, warm) | ~0.26 ms (avg of 100 calls) |
| Artifact size on disk | ~35 KB |

The one-time cold-start cost is import overhead shared by any
`scikit-learn`-based module (also present in `app.ml`), not something
specific to this model's size — the model itself (one 16-unit hidden
layer, 42 inputs, 3 outputs) is tiny, and warm inference is effectively
instantaneous relative to a typical camera frame interval (30 FPS ≈ 33
ms/frame). No performance optimization was needed or added.

## 14. Limitations

- **Single-frame classification, not motion:** `WAVE` is, in reality, a
  motion gesture. This phase classifies a single static landmark
  snapshot (matching the per-frame architecture already used by
  `app.vision`), so `WAVE` is approximated here as a distinctive raised,
  off-center static hand pose rather than true multi-frame motion
  detection. Genuine motion-based gesture recognition (e.g. classifying
  a short sequence of frames) is a reasonable candidate for a future
  phase, not this one.
- **Synthetic training data:** see "Training process" above — the
  dataset is generated from documented geometric templates, not real
  camera footage, due to this environment's hardware/network
  constraints.

## 15. Future integration point

This phase adds `app.dl` as a self-contained module that is **ready**
for future integration. It does not modify `app.main`, and it does not
call `Decision`, `Robot`, `Navigation`, `Guide`, or `UI`. A future
phase may:

- add a real landmark-extraction stage (populating the same 42-float
  schema `app.dl.models.landmark_schema` already defines) from actual
  camera frames;
- feed `GestureResult` (alongside `app.vision`'s `DetectionResult` and
  `app.ml`'s `IntentResult`) into the Decision layer to drive robot
  behavior.

**P1-DL does not integrate with Decision or Robot.**
