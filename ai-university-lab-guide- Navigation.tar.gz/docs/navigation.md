# Navigation — University Map & Route Planning

Owner: Person 1 (AI / Intelligence).

## 1. Purpose

Given a starting location and a destination, compute a route between
them. Nothing more.

Navigation answers: **"How do I get there?"**
Guide answers: **"What is this place?"**
These stay separate — Navigation does not import or depend on Guide.

## 2. Architecture

```
origin, destination (str)
      |
      v
NavigationService.find_route()   (app.navigation.service)
      |
      v
NavigationResult                  (app.models.schemas)
```

Internally:

```
app.navigation.service
      |
      v
app.navigation.pathfinder   (Dijkstra — pure graph algorithm)
      |
      v
app.navigation.map_data     (static in-memory university map)
```

Navigation only computes a route — it does not decide *when* to
navigate (a future Decision responsibility), does not understand
student language (`app.ml`), does not use gesture information
(`app.dl`), and does not move the robot (`app.robot`).

### Package layout

```
app/navigation/
├── __init__.py     module overview
├── map_data.py      static university map (locations + weighted edges)
├── pathfinder.py     Dijkstra shortest-path algorithm (pure graph logic)
└── service.py         public API: NavigationService
```

No `models.py` was added: the only navigation-specific contract needed
(`NavigationResult`) is a shared, cross-module contract and lives in
`app.models.schemas` alongside `IntentResult` and `GestureResult`,
following the same precedent set by `app.ml` and `app.dl`.

## 3. Map representation

The map is a small, static, in-memory **undirected weighted graph**:

- **Nodes:** location ids (plain strings, e.g. `"MAIN_GATE"`).
- **Edges:** `(location_a, location_b, distance)` — bidirectional,
  since the campus paths between these locations are walkable in
  either direction.

Distances are **simulated demonstration values** (approximate walking
distance in meters), not measurements of any real institution — no
existing location or distance data existed in the project prior to
this phase, so this map is newly introduced and clearly documented as
illustrative.

`app.navigation.map_data.build_adjacency()` converts the edge list into
an adjacency dict (`{location: {neighbor: distance}}`) that
`app.navigation.pathfinder` searches over.

## 4. Locations

| Location id | Notes |
|---|---|
| `MAIN_GATE` | Campus entrance |
| `ADMINISTRATION` | |
| `LIBRARY` | |
| `COMPUTER_BUILDING` | |
| `AI_LAB` | |
| `ROBOTICS_LAB` | |
| `LECTURE_HALL_A` | |
| `LECTURE_HALL_B` | |
| `STUDENT_AFFAIRS` | |
| `CAFETERIA` | |
| `OLD_ANNEX` | Intentionally disconnected (no edges) — exists specifically to make unreachable-destination behavior demonstrable and testable. |

11 locations total — enough to demonstrate direct routes, multi-step
routes, an alternative-path choice, and an unreachable location,
without an inflated fake campus.

## 5. Routing algorithm

**Dijkstra's algorithm**, chosen per this phase's own guidance: the map
has weighted edges (simulated distances), so Dijkstra applies rather
than plain BFS (which would only be correct for equal-cost edges). A*
was not introduced — there is no heuristic need for it here, and it
would add complexity without a real benefit at this map's size.

Implementation notes (`app.navigation.pathfinder.find_shortest_path`):

- Standard `heapq`-based Dijkstra.
- Ties in path cost are broken by comparing location id strings
  (via natural tuple comparison on `(distance, location)` heap
  entries), so output is **fully deterministic** regardless of
  dict/heap iteration order.
- The algorithm is isolated from the public service API — callers of
  `NavigationService` never see graph, heap, or node internals.

## 6. Route representation

A route is an ordered list of location ids, inclusive of both
endpoints:

```python
["MAIN_GATE", "ADMINISTRATION", "COMPUTER_BUILDING", "AI_LAB"]
```

- Always starts at `origin` and ends at `destination`.
- Contains only valid map node ids.
- Never contains a cycle (Dijkstra never revisits a node).
- `origin == destination` returns the trivial single-element route
  `[origin]` with `distance=0.0`.

## 7. `NavigationResult` contract

Defined in `app/models/schemas.py` (the project's single canonical
contracts module, alongside `IntentResult` from `app.ml` and
`GestureResult` from `app.dl`):

```python
@dataclass(frozen=True)
class NavigationResult:
    success: bool
    origin: str
    destination: str
    route: List[str] = field(default_factory=list)   # empty when success is False
    distance: Optional[float] = None                  # None when unavailable
    error: Optional[str] = None                        # set when success is False
```

Validated invariants (enforced in `__post_init__`):
- When `success=True`: `route` is non-empty, starts at `origin`, ends
  at `destination`.
- When `success=False`: `error` is set (non-empty).
- `distance`, if present, is `>= 0`.

This is the **only** `NavigationResult` definition in the project — no
duplicate was created; `app/models/` was inspected first, per this
phase's own instructions, and confirmed nothing suitable already
existed.

## 8. Public API

```python
from app.navigation.service import NavigationService

navigation = NavigationService()
result = navigation.find_route("MAIN_GATE", "AI_LAB")
# NavigationResult(success=True, origin="MAIN_GATE", destination="AI_LAB",
#                   route=["MAIN_GATE", "ADMINISTRATION", "COMPUTER_BUILDING", "AI_LAB"],
#                   distance=270.0, error=None)
```

`NavigationService` has exactly one public method: `find_route(origin,
destination) -> NavigationResult`. Callers never need to know about the
graph structure, the routing algorithm, or how the map is stored.

Location ids passed in are normalized (trimmed and uppercased) before
lookup, so `"main_gate"` and `" AI_LAB "` work the same as
`"MAIN_GATE"` / `"AI_LAB"`.

## 9. Error handling

`find_route` never raises for ordinary bad input — it always returns a
structured `NavigationResult(success=False, error=...)`:

| Situation | Result |
|---|---|
| Unknown origin | `success=False`, `error="Unknown origin location: ..."` |
| Unknown destination | `success=False`, `error="Unknown destination location: ..."` |
| Destination unreachable from origin | `success=False`, `error="No route found between ... (unreachable)"` |
| Non-string / `None` input | Coerced to text, then handled as an unknown location (never crashes) |

No fake or partial route is ever returned on failure — `route` is
always `[]` when `success=False`.

## 10. Testing

```bash
# Navigation tests only
pytest tests/navigation/ -v

# Full suite (existing + ML + DL + Navigation)
pytest -v
```

Tests are fully independent of hardware and other modules: they
exercise `map_data`, `pathfinder`, and `service` directly with no
camera, robot, robot SDK, ML, DL, Vision, Decision, Guide, UI, or
network dependency. `tests/navigation/test_service.py` also includes a
static AST-based guardrail confirming `app.navigation` never imports
`app.ml`, `app.dl`, `app.vision`, `app.robot`, `app.decision`,
`app.guide`, `app.ui`, or `app.main`.

## 11. How to extend the map

1. Add a new location id constant to `app/navigation/map_data.py` and
   include it in `LOCATIONS`.
2. Add one or more `(location_a, location_b, distance)` entries to
   `_EDGES` connecting it to the existing graph (or leave it
   unconnected, like `OLD_ANNEX`, to represent an intentionally
   unreachable location).
3. Re-run `pytest tests/navigation/` to confirm the map is still
   internally consistent (symmetric adjacency, positive distances,
   etc.) and that no existing test's expected route/distance changed
   unexpectedly.
4. If the new location changes an existing shortest path, update the
   corresponding expected values in `tests/navigation/test_pathfinder.py`
   / `test_service.py`.

## 12. Future integration point

This phase adds `app.navigation` as a self-contained module that is
**ready** for future integration. It does not modify `app.main`, and
it does not call `Decision`, `Robot`, `Guide`, `Vision`, `ML`, or `DL`.

The future system flow (not implemented here):

```
Decision
    ↓
NavigationService.find_route(origin, destination)
    ↓
NavigationResult
    ↓
main.py
    ↓
Robot
```

**P1-Navigation stops at `NavigationResult`.** It does not integrate
with Decision, Robot, Guide, Vision, ML, DL, or `main.py`.
